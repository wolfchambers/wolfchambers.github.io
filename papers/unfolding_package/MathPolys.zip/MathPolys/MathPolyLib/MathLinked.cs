﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolyLink
{
    public class MathLinked
    {
        public MathLinked()
        {
            ML = new KernelDispatch();
        }

        public IKernelDispatch ML { get; set; }
    }
}
