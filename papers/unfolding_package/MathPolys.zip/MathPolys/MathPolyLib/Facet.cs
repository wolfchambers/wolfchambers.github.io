﻿using System;
using System.Collections.Generic;
using System.Linq;
using Wolfram.NETLink;

namespace PolyLink
{
    /// <summary>
    /// Facets are little more than a link to a HalfEdge, but they provide a convenient interface for manipulating Polyhedrons.
    /// Presently, Facets are not guaranteed to be coplanar, convex, and they can be totally broken.
    /// </summary>
    public class Facet : MathLinked
    {
        private static readonly Expr _p110 = MSingle.Eval("{1,1,0}");
        private static readonly PointRef _ref110 = new PointRef(_p110);

        /// <summary>
        /// A tag string for this facet. Useful for debugging.
        /// </summary>
        public string Tag { get; set; }

        /// <summary>
        /// Constructs a facet
        /// </summary>
        /// <param name="head">A half-edge which is designated as the head. This half-edge should already be part of a loop of HalfEdges which make the sides of this facet.</param>
        /// <param name="color">A color for when the facet is represented graphically. Defaults to White.</param>
        public Facet(HalfEdge head, string color = "RGBColor[1,1,1]")
        {
            Head = head;
            Expr c = ML[color].Eval();
            if (c.Head != MathConstants.ColorHead)
                throw new ArgumentException("argument 'color' does not resolve into a Mathematica color");
            Color = c;
        }

        /// <summary>
        /// Placeholder convexity checker.
        /// </summary>
        public bool Convex
        {
            get
            {
                Console.WriteLine("Assuming this facet is convex.");
                return true;
            }
        }

        /// <summary>
        ///     This facet's color when drawn with Mathematica
        /// </summary>
        public Expr Color { get; set; }

        /// <summary>
        ///     A HalfEdge around this facet designated arbitrarily as the head. Does not change.
        /// </summary>
        public HalfEdge Head { get; set; }

        /// <summary>
        ///     Point-normal form of the plane on which this facet lies
        /// </summary>
        public Plane Plane
        {
            get { return Head.Plane; }
        }

        /// <summary>
        /// Goes through all Half-Edges of this Facet and forces them to reference this Facet in their "Facet" field.
        /// </summary>
        public void ForceHalfEdgesToReferenceThis()
        {
            foreach (var he in HalfEdges)
            {
                he.Facet = this;
            }
        }

        /// <summary>
        ///     Enumerates the HalfEdges around this facet starting from Head
        /// </summary>
        public IEnumerable<HalfEdge> HalfEdges
        {
            get { return Head.HEsFromHere; }
        }

        public HalfEdge[] HalfEdgeArray
        {
            get { return HalfEdges.ToArray(); }
        }

        /// <summary>
        ///     Mathematica graphics object which represents the facet
        /// </summary>
        public Expr Graphics
        {
            get
            {
                return ML["List"].Bracket(
                    ML["List"].Bracket(
                        Color,
                        PolyPrimitive
                        ).Eval()
                    ).Eval();
            }
        }

        private Expr PolyPrimitive
        {
            get
            {
                return ML["Polygon"].Bracket(
                    ML["List"].Bracket(
                        HalfEdges.Select(he => he.Start.Expr)
                        ).Eval()
                    ).Eval();
            }
        }

        /// <summary>
        /// Returns this facet, but colored Yellow. A good usage of this property is to call
        /// Graphics3D[{poly@Graphics,facet@Highlight}]
        /// in Mathematica, which will give you a graphical representation of the polygon, but with this facet highlighted.
        /// </summary>
        public Expr Highlight
        {
            get
            {
                return ML["List"].Bracket(
                    ML["List"].Bracket(
                        ML["Glow[Yellow]"].Eval(),
                        PolyPrimitive
                        ).Eval()
                    ).Eval();
            }
        }

        /// <summary>
        ///     Enumerates the vertices of this facet
        /// </summary>
        public IEnumerable<PointRef> PointRefs
        {
            get { return HalfEdges.Select(he => he.Start); }
        }

        /// <summary>
        ///     An array of every vertex of this facet
        /// </summary>
        public PointRef[] PointRefArray
        {
            get { return PointRefs.ToArray(); }
        }

        /// <summary>
        ///     A Mathematica List of the coordinates of every vertex
        /// </summary>
        public Expr Points
        {
            get { return ML["List"].Bracket(PointRefs.Select(p => p.Expr)).Eval(); }
        }

        //Static methods

        /// <summary>
        /// Used for testing. Creates a small square facet in the xy plane.
        /// </summary>
        public static Facet TestQuad
        {
            get
            {
                var a = new HalfEdge(PointRef.OriginRef, PointRef.Ref100);
                var b = new HalfEdge(a.End, _ref110);
                var c = new HalfEdge(b.End, PointRef.Ref010);
                var d = new HalfEdge(c.End, a.Start);

                a.LinkNext(b);
                b.LinkNext(c);
                c.LinkNext(d);
                d.LinkNext(a);

                return new Facet(a);
            }
        }

        /// <summary>
        /// Creates a clone of this Facet that has all new HalfEdges and PointRefs in it, but in the same location in space.
        /// </summary>
        public Facet CloneWithAllHalfEdgesCloned
        {
            get
            {

                return new Facet(Head.FacetRingClone, Color.ToString());
            }
        }

        /// <summary>
        ///     Subdivides this facet with an edge from v1 to v2.
        /// </summary>
        /// <param name="v1">A vertex of this facet</param>
        /// <param name="v2">A different vertex of this facet</param>
        /// <returns>The new facet object created by this operation (does not contain Head)</returns>
        public Facet SubDivide(PointRef v1, PointRef v2)
        {

            HalfEdge he1 = HalfEdges.First(he => he.Start == v1);
            HalfEdge he2 = HalfEdges.First(he => he.Start == v2);
            HalfEdge he2P = he2.Prev;

            HalfEdge[] newHes = he1.Prev.DetourToVertex(v2);

            newHes[0].LinkNext(he2);
            he2P.LinkNext(newHes[1]);
            newHes[1].LinkNext(he1);

            var facet = new Facet(newHes[0]);

            foreach (HalfEdge halfEdge in newHes[0].HEsFromHere)
            {
                halfEdge.Facet = facet;
            }

            return new Facet(newHes[0]);
        }

        /// <summary>
        /// Triangulates this Facet and returns any new Facets that get created in the process.
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Facet> Triangulate()
        {
            Console.WriteLine("Triangulating!");
            return HalfEdges.Skip(3)
                            .Select(he => he.Start).ToList()
                            .Select(vert => SubDivide(vert, Head.End));
        }

        /// <summary>
        /// Checks to see is this Facet intersects an Endpointpacket
        /// </summary>
        /// <param name="p">An EndPointPacket that may intersect this Facet</param>
        /// <returns>True if the EndPointPacket does intersect this Facet.</returns>
        public bool CheckIntersectSlow(EndPointPacket p)
        {
            //Console.WriteLine("c1");
            Expr t = FindIntersectSlow(p);
            //Console.WriteLine("c2");
            if (t == null)
                return false;
            Expr point = ML["{0}*{1} + (1-{0})*{2}"].Format(t, p.StartRef.Expr, p.EndRef.Expr).Eval();
            //Console.WriteLine("c3");
            Expr cp =
                ML["Cross[{1} - {0},{2} - {0}]"].Format(point, PointRefs.Last().Expr, PointRefs.First().Expr).Eval();
            //Console.WriteLine("c4");
            return !PointRefs.CirclularPairs()
                        //.Print(any => "c5")
                             .Select(
                                 pair =>
                                 ML["Cross[{1} - {0},{2} - {0}]"].Format(point, pair.Item1.Expr, pair.Item2.Expr)
                                                                 .Eval())
                        //.Print(any => "c6")
                             .Any(crossProduct => (bool) ML["Dot[{0},{1}] <= 0"].Format(cp, crossProduct).EvalObject());
        }

        private Expr FindIntersectSlow(EndPointPacket p)
        {
            //Console.WriteLine("f1");
            Expr tNum =
                ML["Dot[{0},{1}] - Dot[{2},{1}]"].Format(p.EndRef.Expr, Plane.Normal, Plane.Point)
                                                 .FullSimplify()
                                                 .Eval();
            //Console.WriteLine("f2");
            Expr tDenom =
                ML["Dot[{0}.{1}] - Dot[{1}.{2}]"].Format(p.EndRef.Expr, Plane.Normal, p.StartRef.Expr)
                                                 .FullSimplify()
                                                 .Eval();
            //Console.WriteLine("f3");
            if ((bool) ML["{0} == 0"].Format(tDenom).FullSimplify().EvalObject())
            {
                //Console.WriteLine("f4a");
                //Either on plane or parallel
                if ((bool) ML["{0} == 0"].Format(tNum).FullSimplify().EvalObject())
                {
                    return "(1/2)".MsEvalWith();
                }
                return null;
            }
            //Console.WriteLine("f4b");
            Expr q = ML["{0}/{1}"].Format(tNum, tDenom).FullSimplify().Eval();
            // Console.WriteLine("f5b");
            return ((bool) ML["{0} > 0 && {0} < 1"].Format(q).FullSimplify().EvalObject())
                       ? q
                       : null;
        }

        /// <summary>
        /// Checks to see if Facet f intersects with this Facet.
        /// </summary>
        /// <param name="f">Facet that may intersect with this one</param>
        /// <returns>True if there is an intersection</returns>
        public bool CheckIntersectSlow(Facet f)
        {
            if (PlaneCheck(f))
            {
                return false;
            }
            return HalfEdges.Any(he => f.CheckIntersectSlow(he.EndPointPacket));
        }

        private bool PlaneCheck(Facet f)
        {
            Expr normal = Plane.Normal;

            bool pointsInFront = false;
            bool pointsInBack = false;

            Expr headPt = Head.Start.Expr;

            foreach (Expr vector in f.PointRefs
                                     .Select(pr => pr.Expr)
                                     .Select(p =>
                                             ML["{0} - {1}"].Format(p, headPt).Eval()))
            {
                Expr dot = ML["Dot"].Bracket(vector, normal).FullSimplify().Eval();
                if ((bool) ML["{0} > 0"].Format(dot).EvalObject())
                {
                    pointsInFront = true;
                }
                if ((bool) ML["{0} < 0"].Format(dot).EvalObject())
                {
                    pointsInBack = true;
                }
                if (pointsInBack && pointsInFront)
                {
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// Finds the 'Midpoint' of this Facet by averaging all the vertices together.
        /// </summary>
        public Expr Midpoint
        {
            get { return ML["Mean"].Bracket(Points).Eval(); }
        }

        /// <summary>
        /// Creates a graphics primitive representing an inset label floating .1 units above the facet.
        /// </summary>
        /// <param name="labelNumber">Number with which to label the facet</param>
        /// <returns>The graphics primitive for the label</returns>
        public Expr InsetLabel(int labelNumber)
        {
            var labelpoint = ML["{0} + .1*{1}"].Format(Midpoint, Plane.Normal).Eval();
            return ML["Inset"].Bracket(labelNumber, labelpoint).Eval();
        }

        /// <summary>
        /// Creates a graphics primitive representing a label which can't be covered up
        /// </summary>
        /// <param name="labelNumber">Number with which to label the facet</param>
        /// <returns>The graphics primitive for the label</returns>
        public Expr ClipLabel(int labelNumber)
        {
            return ML["Text"].Bracket(labelNumber, Midpoint).Eval();
        }

        /// <summary>
        /// Generates labels for the halfEdges
        /// </summary>
        /// <param name="startFrom">The head HalfEdge gets this label, and the labels for the other HalfEdges increase from there</param>
        /// <returns>The graphics primitive for the labels</returns>
        public Expr HELabelsStartingFrom(int startFrom)
        {
            var labels = Enumerable.Range(startFrom, int.MaxValue).NetZip(HalfEdges, (i, h) => h.Label(i));
            return
                ML["List"].Bracket
                (
                    ML["List"]
                        .Bracket(labels)
                        .Eval()
                ).Eval();
        }

        /// <summary>
        /// Generates labels for the HalfEdges, starting from 1.
        /// </summary>
        public Expr HELabels
        {
            get { return HELabelsStartingFrom(1); }
        }

        /// <summary>
        /// Allows the user to pick a HalfEdge by cross-referencing with the HELabels
        /// </summary>
        /// <param name="i">The HalfEdge index, where 1 is Head, 2 is Head.Next, and so forth</param>
        /// <returns>The selected HalfEdge</returns>
        public HalfEdge PickHalfEdge(int i)
        {
            return HalfEdges.Skip(i - 1).First();
        }

        /// <summary>
        /// Assuming the vertices on this facet are coplanar, gives the normal of this facet.
        /// </summary>
        public Expr Normal
        {
            get { return Plane.Normal; }
        }

        /// <summary>
        /// Gives a graphical representation of the Normal vector for this facet.
        /// </summary>
        public Expr NormalGraphics
        {
            get
            {
                return ML["List[ {{Purple, Arrow[ {{ {0}, {0} + .5*{1} }} ] }} ]"].Format(Midpoint, Normal).Eval();
            }
        }

        /// <summary>
        /// Highlights the HalfEdges of this Facet.
        /// </summary>
        public Expr HEHighlights
        {
            get
            {
                return ML["List"].Bracket(
                    ML["List"].Bracket(HalfEdges.Select(he => he.Highlight)).Eval()
                    ).Eval();
            }
        }
    }
}