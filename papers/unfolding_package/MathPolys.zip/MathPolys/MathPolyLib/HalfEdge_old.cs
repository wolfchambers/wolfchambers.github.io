﻿using System;
using System.Collections.Generic;
using System.Linq;
using Wolfram.NETLink;

namespace MathPolyLib
{
    /// <summary>
    /// A directed edge which bounds a facet and links to neighboring HalfEdges
    /// </summary>
    //public class HalfEdge : MathLinked
    //{
        /*
        /// <summary>
        /// Constructs HalfEdge but does not link it to its neighbors
        /// </summary>
        /// <param name="start">Start point</param>
        /// <param name="end">End point</param>
        public HalfEdge(PointRef start, PointRef end)
        {
            _start = start;
            _end = end;
        }

        public Facet Facet { get; set; }

        /// <summary>
        /// Exports the EndpointPacket for this HalfEdge
        /// </summary>
        public EndPointPacket EndPointPacket
        {
            get
            {
                return new EndPointPacket(Start, End);
            }
        }

        /// <summary>
        /// Exports the OppositeEndpointPacket for this HalfEdge
        /// </summary>
        public EndPointPacket OppositesEndPointPacket
        {
            get
            {
                return EndPointPacket.Opposite;
            }
        }

        public PointRef Start
        {
            get { return _start; }
            set { _start = value; }
        }

        public PointRef End
        {
            get { return _end; }
            set { _end = value; }
        }

        protected PointRef _start;
        protected PointRef _end;

        protected HalfEdge _opposite;

        /// <summary>
        /// The HalfEdge which represnts the same edge but bounds a neighboring facet
        /// </summary>
        public HalfEdge Opposite
        {
            get { return _opposite; }
            set
            {
                _opposite = value;
            }
        }

        protected HalfEdge _next;
        protected HalfEdge _prev;

        /// <summary>
        /// The next HalfEdge going counterclockwise
        /// </summary>
        public HalfEdge Next
        {
            get { return _next; }
        }

        /// <summary>
        /// The previous Halfedge
        /// </summary>
        public HalfEdge Prev
        {
            get { return _prev; }
        }

        /*private List<HalfEdge> InsertAfter(HalfEdge he)
        {
            //Acting upon this
            var oldNext = _next;
            _next = he;

            //Acting upon he
            var retList = new List<HalfEdge>();
            if (he._next != null)
            {
                he._next._prev = null;
                retList.Add(he._next);
            }
            if (he._prev != null)
            {
                he._prev._next = null;
                retList.Add(he._prev);
            }
            he._next = oldNext;
            he._prev = this;
            return retList;
        }

        /// <summary>
        /// Enumerates the halfedges around the facet that this binds
        /// </summary>
        public IEnumerable<FoldingHalfEdge> HEsFromHere
        {
            get
            {
                yield return this;
                var he = this.Next;
                while (he != this)
                {
                    yield return he;
                    he = he.Next;
                }
            }
        }

        public IEnumerable<HalfEdge> HEsFromHereReversed
        {
            get
            {
                yield return this;
                var he = this.Prev;
                while (he != this)
                {
                    yield return he;
                    he = he.Prev;
                }
            }
        }

        /// <summary>
        /// Gives the displacement vector from Start to End
        /// </summary>
        public Expr AsVectorExpr
        {
            get { return EndPointPacket.AsVectorExpr; }
        }

        /// <summary>
        /// Gives the plane containing this HalfEdge
        /// </summary>
        public Plane Plane
        {
            get
            {
                Expr point = Start.Point;
                Expr normal = ML["Normalize[Cross[{0},{1}]]"].Format(this.AsVectorExpr, Next.AsVectorExpr).FullSimplify().Eval();
                return new Plane(point, normal);
            }
        }

        /// <summary>
        /// Dots this halfedge's facet with the facet's neighbor along this halfedge.
        /// </summary>
        public Expr DotOpposite
        {
            get { return ML["Dot[{0},{1}]"].Format(this.Plane.Normal, Opposite.Plane.Normal).Eval(); }
        }

        /// <summary>
        /// Create a pair of Half-Edges following this one, which go from this's End to p, and back again
        /// </summary>
        /// <param name="p"></param>
        public HalfEdge[] DetourToVertex(PointRef p)
        {
            var ret = new HalfEdge[2];
            var outHE = new HalfEdge(End, p)
                {
                    Facet = Facet
                };
            var backHE = new HalfEdge(p, End)
                {
                    Facet = Facet
                };
            outHE.Opposite = backHE;
            backHE.Opposite = outHE;

            var oldNext = _next;
            _next = outHE;
            outHE._prev = this;
            outHE._next = backHE;
            backHE._prev = outHE;
            backHE._next = oldNext;

            ret[0] = outHE;
            ret[1] = backHE;
            return ret;
        }

        /// <summary>
        /// Links a HalfEdge to this one and saves references to possibly unlinked HalfEdges 
        /// </summary>
        /// <param name="he">HalfEdge which will become the new next</param>
        /// <returns>Small Dictionary. Value[this] is the old Next of this. Value[he] is the old Prev of he.</returns>
        public Dictionary<HalfEdge, HalfEdge> LinkNext(HalfEdge he)
        {
            var d = new Dictionary<HalfEdge, HalfEdge>();
            d[this] = Next;
            d[he] = he.Prev;
            _next = he;
            he._prev = this;
            return d;
        }

        /// <summary>
        /// Returns true iff opposite is null
        /// </summary>
        public bool OppIsNull
        {
            get { return Opposite == null; }
        }

        /// <summary>
        /// Removes this HalfEdge and joins two neighboring facets
        /// </summary>
        public void MergeAcross()
        {
            var prev = Prev;
            prev.LinkNext(Opposite.Next);
            Opposite.Prev.LinkNext(Next);
            Opposite.Facet.Head = null;
            foreach (var halfEdge in prev.HEsFromHere)
            {
                halfEdge.Facet = Facet;
            }
        }

        public override string ToString()
        {
            return String.Format("[{0} to {1}]", Start, End);
        }

        /// <summary>
        /// Enumerates all HalfEdges which have End as their end point
        /// </summary>
        public IEnumerable<HalfEdge> CycleAboutEndPoint
        {
            get
            {
                yield return this;
                var he = this.Next.Opposite;
                while (he != this)
                {
                    yield return he;
                    he = he.Next.Opposite;
                }
            }
        }
        
        /// <summary>
        /// Turns the dot product of this and next
        /// </summary>
        public Expr DotNext
        {
            get { return ML["Dot"].Bracket(this.AsVectorExpr, this.Next.EndPointPacket.Opposite.AsVectorExpr).Eval(); }
        }

        /// <summary>
        /// Angle between this and next
        /// </summary>
        public Expr AngleToNext
        {
            get
            {
                return ML["ArcCos[{0}] / ({1} * {2})"].Format(this.DotNext, this.EndPointPacket.Magnitude,
                                                            this.Next.EndPointPacket.Magnitude).Eval();
            }
        }

        /// <summary>
        /// Sum of all angles around this vertex
        /// </summary>
        public Expr SumAngles
        {
            get
            {
                return this.CycleAboutEndPoint.Select(he => he.AngleToNext).Aggregate((a1, a2) => ML["{0} + {1}"].Format(a1,a2).Eval());
            }
        }

        public FoldingHalfEdge AsFoldingHalfEdge
        {
            get { return (this as FoldingHalfEdge); }
        }

        /// <summary>
        /// Curvature of this vertex
        /// </summary>
        public Expr Curvature
        {
            get { return ML["2*Pi - {0}"].Format(SumAngles).Eval(); }
        }

        public virtual Expr Graphics
        {
            get { return null; }
        }

        public Expr Highlight
        {
            get { return ML["GraphicsGroup[ {{ Thick, Red, Arrow[ {{ {0},{1} }} ] }} ]"].Format(Start.Point, End.Point).Eval(); }
        }

        //Static methods

        private static readonly HalfEdge littleLine = new HalfEdge(PointRef.OriginRef, PointRef.Ref100);
        private static readonly HalfEdge line2 = new HalfEdge(PointRef.Ref100, PointRef.Ref010);
        private static readonly HalfEdge line3 = new HalfEdge(PointRef.Ref010, PointRef.OriginRef);

        /// <summary>
        /// For testing
        /// </summary>
        public static HalfEdge LittleLine
        {
            get { return littleLine; }
        }

        /// <summary>
        /// For testing
        /// </summary>
        public static HalfEdge Facetable
        {
            get
            {
                if (LittleLine.Next == null)
                {
                    LittleLine.LinkNext(line2);
                    line2.LinkNext(line3);
                    line3.LinkNext(LittleLine);
                }
                return LittleLine;
            }
        }

        //TODO this function doesn't work. And we don't run it very often.
        public virtual HalfEdge FacetRingClone
        {
            get
            {
                throw new NotImplementedException();
                /*
                var cloneRing = HEsFromHere.Select(he => he.ShallowClone).Skip(1).ToList();
                var prev = this.ShallowClone;
                var myClone = prev;

                foreach (var he in cloneRing.Concat(new[] {myClone}))
                {
                    he.Start = he.Start.DeepClone;
                    he.End = he.End.DeepClone;
                    he._prev = prev;
                    prev._next = he;
                }
                return myClone;
            }
        }

        protected virtual HalfEdge ShallowClone
        {
            get
            {
                throw new NotImplementedException();
                /*
                var n = new HalfEdge(Start, End){
                    _next = Next,
                    _prev = Prev,
                    _opposite = null};
                return n;
            }
        }

        public Expr NormalGraphics
        {
            get { return ML["GraphicsGroup[ {{Purple, Arrow[ {{ {0}, {0} + {1} }} ] }} ]"].Format(End.Point, Plane.Normal).Eval(); }
        }
        */
    //}
}