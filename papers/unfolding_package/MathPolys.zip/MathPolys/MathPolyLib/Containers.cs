﻿using System.Text;
using System.Threading.Tasks;
using Wolfram.NETLink;

namespace PolyLink
{
    //TODO Figure out how to MathLink up them Structs! fool

    /// <summary>
    /// A container for a Halfedge's start and end points. An immutable container.
    /// </summary>
    public struct EndPointPacket
    {
        private readonly PointRef _startRef;
        private readonly PointRef _endRef;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="startRef">Reference to the Start Point of the EndPointPacket</param>
        /// <param name="endRef">Reference to the End Point of the EndPointPacket</param>
        public EndPointPacket(PointRef startRef, PointRef endRef) : this()
        {
            _startRef = startRef;
            _endRef = endRef;
        }

        /// <summary>
        /// Reference to the Start Point of the EndPointPacket
        /// </summary>
        public PointRef StartRef
        {
            get { return _startRef; }
        }

        /// <summary>
        /// Reference to the End Point of the EndPointPacket
        /// </summary>
        public PointRef EndRef
        {
            get { return _endRef; }
        }

        /// <summary>
        /// An EndPointPacket with the start and end points swapped
        /// </summary>
        public EndPointPacket Opposite
        {
            get
            {
                return new EndPointPacket(EndRef, StartRef);
            }
        }

        /// <summary>
        /// The displacement vector from Start to End
        /// </summary>
        public Expr AsVector
        {
            get { return EndRef - StartRef; }
        }

        /// <summary>
        /// The distance from start to end
        /// </summary>
        public Expr Magnitude
        {
            get
            {
                return "Sqrt".MsBracket(
                    "Dot".MsBracket(new[] {this.AsVector, this.AsVector}));
            }
        }
    }

    /// <summary>
    /// Point-normal representation of the plane containing this HalfEdge. An immutable container.
    /// </summary>
    public struct Plane
    {
        private readonly Expr _point;
        private readonly Expr _normal;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="point">Point that this plane passes through</param>
        /// <param name="normal">Normal to the plane</param>
        public Plane(Expr point, Expr normal) : this()
        {
            _normal = "Normalize".MsBracket(normal);
            _point = point;
        }

        /// <summary>
        /// Point that this plane passes throug
        /// </summary>
        public Expr Point
        {
            get { return _point; }
        }

        /// <summary>
        /// Normal to the plane
        /// </summary>
        public Expr Normal
        {
            get { return _normal; }
        }



        //Static methods for unit testing
        public static Expr UpVec
        {
            get { return _upVec; }
        }

        private static readonly Expr _upVec = "{0,1,0}".MsEvalWith();

        /// <summary>
        /// Returns a vector seated at the origin pointing upwards in the Y direction
        /// </summary>
        public static Plane TestOriginUp
        {
            get
            {
                return new Plane(PointRef.Origin, UpVec);
            }
        }
         /// <summary>
         /// Projects point q onto the plane
         /// </summary>
         /// <param name="q">Expression for a point in 3D space</param>
         /// <returns>Projection of q</returns>
        public Expr ProjectPoint(Expr q)
        {
            var vec = "{0} - {1}".MsEvalWith(q, Point);
            var dist = "Dot[{0},{1}]".MsEvalWith(vec, Normal);
            return "{0} - {1} * {2}".MsEvalWith(q, dist, Normal);
        }
    }
}
