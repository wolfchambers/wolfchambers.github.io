﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wolfram.NETLink;

namespace PolyLink
{
    static class MathConstants
    {
        /// <summary>
        /// The Mathematica Head for a color
        /// </summary>
        public static readonly Expr ColorHead = MSingle.Eval("Head[Blue]");
    }
}
