﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wolfram.NETLink;

namespace PolyLink
{
    /*
    public static class HelloWorld
    {
        public static void PrintHelloWorld()
        {
            var ml = MathLinkFactory.CreateKernelLink();
            ml.WaitAndDiscardAnswer();

            Console.WriteLine(ml.EvaluateToOutputForm("Hello Mathematica",0));
        }

        public static Expr HelloWorldExpression()
        {

            var ml = MathLinkFactory.CreateKernelLink();
            ml.WaitAndDiscardAnswer();


            ml.Evaluate("Append[{\"Hello Mathematica\"},\"Again!\"]");
            ml.WaitForAnswer();
            Expr e = ml.GetExpr();
            ml.Close();
            return e;
        }

        public static String HelloWorldExpressionString()
        {

            var ml = MathLinkFactory.CreateKernelLink();
            ml.WaitAndDiscardAnswer();


            ml.Evaluate("Append[{\"Hello Mathematica\"},\"Again!\"]");
            ml.WaitForAnswer();
            return ml.GetExpr().ToString();
        }

        public static int ReturnTwo()
        {
            return 2;
        }

        public static IEnumerable<Expr> TenExpressions
        {
            get { return Enumerable.Range(0, 10).Select(x => MSingle.Eval(x.ToString())); }
        }

        public static Expr TestEnumerableToList()
        {
            return TenExpressions.AsListExpr();
        }

        public static Expr AsListExpr(this IEnumerable<Expr> exprList)
        {
            String s = "{" + String.Join(",", exprList.Select(e => e.ToString())) + "}";
            MSingle.Kernel.Evaluate(s);
            MSingle.Kernel.WaitForAnswer();
            var evaluated = MSingle.Kernel.GetExpr();
            return evaluated;
        }

        public static Expr TestEnumerableToListQuick()
        {
            return "List".MsBracket(TenExpressions);
        }
    }*/
}
