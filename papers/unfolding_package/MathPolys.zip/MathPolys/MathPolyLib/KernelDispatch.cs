﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wolfram.NETLink;

namespace PolyLink
{
    /// <summary>
    /// Object allowing for a more clear and intuitive interface to the Mathematica kernel. Still a WIP.
    /// </summary>
    public class KernelDispatch : IKernelDispatch
    {
        public static int KernelWait = 1;

        private readonly IKernelLink _kernel;

        public KernelDispatch()
        {
            //Set up kernel link
            _kernel = MSingle.Kernel;
            //_kernel.WaitAndDiscardAnswer();
        }

        /// <summary>
        /// The IKernelLink used by this KernelDispatch.
        /// </summary>
        public IKernelLink Kernel
        {
            get { return _kernel; }
        }
        
        /// <summary>
        /// Create an KernelOperation.
        /// </summary>
        /// <param name="s">Mathematica code or function name to be made into a KernelOperation.</param>
        /// <returns>A KernelOperation, ready to be modified or evaluated.</returns>
        public IKernelOperation this[string s]
        {
            get
            {
                return new KernelOperation(_kernel, s);
            }
        }
    }

    public interface IKernelOperation
    {
        /// <summary>
        /// The code to be executed when this KernelOperation is evaluated.
        /// </summary>
        string Command { get; }

        /// <summary>
        /// Link to the Mathematica Kernel
        /// </summary>
        IKernelLink Kernel { get; }

        /// <summary>
        /// Formats the KernelOperation using String.Format(string, args)
        /// </summary>
        /// <param name="args">A set of objects to be formatted into the command</param>
        /// <returns>A new formatted command.</returns>
        KernelOperation Format(params object[] args);

        /// <summary>
        /// Treats the command like the head of a Mathematica function and sets args to be its arguments.
        /// </summary>
        /// <param name="args">Arguments to a function</param>
        /// <returns>A new KernelOperation with the arguments in place</returns>
        KernelOperation Bracket(params object[] args);

        /// <summary>
        /// Treats the command like the head of a Mathematica function and sets args to be its arguments.
        /// </summary>
        /// <param name="args">A collection of argumetns to go into the function</param>
        /// <returns>A new KernelOperation with the arguments in place</returns>
        KernelOperation Bracket<T>(IEnumerable<T> args);

        /// <summary>
        /// Evaluates the Command to a .NET object, which can be cast as a double, int, boolean, etc.
        /// </summary>
        object EvalObject();

        /// <summary>
        /// Evaluates the Command to a Mathematica expression.
        /// </summary>
        Expr Eval();

        /// <summary>
        /// Converts this Command to a re-usable function which takes in and gives out Mathematica Expressions.
        /// </summary>
        Func<Expr, Expr> EvalFunc();

        /// <summary>
        /// Performs a FullSimplify[] Mathematica operation upon the Command.
        /// </summary>
        KernelOperation FullSimplify();
    }

    public struct KernelOperation : IKernelOperation
    {
        private readonly string _command;
        private readonly IKernelLink _kernel;

        public KernelOperation(IKernelLink kernel, string command)
        {
            _kernel = kernel;
            _command = command;
        }

        public string Command
        {
            get { return _command; }
        }

        public IKernelLink Kernel
        {
            get { return _kernel; }
        }

        public void CheckArgs<T>(IEnumerable<T> args)
        {
            if (args.Any(t => t is KernelOperation))
            {
                throw new ArgumentException("Never feed a KernelOperation into another KernelOperation. You probably forgot an Eval somewhere.");
            }
        }

        public KernelOperation Format(params object[] args)
        {
            CheckArgs(args.AsEnumerable());
            return new KernelOperation(Kernel, String.Format(Command, args.Select(o => "(" + o.ToString() + ")").ToArray()));
        }

        public KernelOperation Bracket(params object[] args)
        {
            CheckArgs(args.AsEnumerable());
            return Bracket(args.AsEnumerable());
        }

        public KernelOperation Bracket<T>(IEnumerable<T> args)
        {
            args = args.ToArray();
            CheckArgs(args);
            return new KernelOperation(Kernel,
                String.Format("{0}[{1}]",_command, String.Join(",", args))
                );
        }

        public object EvalObject()
        {
            MaybePrint();
            Kernel.Evaluate(_command);
            Kernel.WaitForAnswer();
            var e = Kernel.GetExpr();
            //Console.WriteLine("Result of EvalObject was {0} characters big", e.ToString().Length);
            Kernel.Evaluate(e);
            Kernel.WaitForAnswer();
            return Kernel.GetObject();

        }



        public Expr Eval()
        {
            MaybePrint();
            Kernel.Evaluate(_command);
            Kernel.WaitForAnswer();
            Expr e = Kernel.GetExpr();
            //Console.WriteLine("Result of Eval was {0} characters big", e.ToString().Length);
            return e;
        }

        public Func<Expr, Expr> EvalFunc()
        {
            var k = Kernel;
            var s = _command;
            return delegate(Expr expr)
                {
                    k.Evaluate(String.Format("{0}[{1}]", s, expr));
                    k.WaitForAnswer();
                    return k.GetExpr();
                };
        }

        public KernelOperation FullSimplify()
        {
            return new KernelOperation(Kernel, String.Format("RootReduce[{0}]",Command));
        }


        private static int x = 0;

        private void MaybePrint()
        {
            x++;
            if (x%1000 == 0)
                Console.WriteLine("Computation number: {0}", x);
        }
    }
}
