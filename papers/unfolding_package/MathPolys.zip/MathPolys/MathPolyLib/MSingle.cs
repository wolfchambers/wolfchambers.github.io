﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wolfram.NETLink;

namespace PolyLink
{
    /// <summary>
    /// A singleton object that communicates with the Mathematica kernel
    /// </summary>
    public sealed class MSingle
    {
        //Singleton code
        private static readonly Lazy<MSingle> Lazy =  new Lazy<MSingle>(() => new MSingle());

        /// <summary>
        /// Gives the instance of the Mathematica kernel
        /// </summary>
        public static MSingle Instance
        {
            get { return Lazy.Value; }
        }

        /// <summary>
        /// The Mathematica kernel link
        /// </summary>
        public static IKernelLink Kernel
        {
            get { return Instance.KernelLink; }
        }

        /// <summary>
        /// The Mathematica kernel link
        /// </summary>
        public IKernelLink KernelLink
        {
            get { return _kernelLink; }
        }

        //Other stuff
        private readonly IKernelLink _kernelLink;

        private MSingle()
        {

            if (((int) System.Environment.OSVersion.Platform).EqualsAny(4,6,128))
            {
                _kernelLink = MathLinkFactory.CreateKernelLink(
                    "-linkmode launch -linkname '\"/Applications/Mathematica.app/Contents/MacOS/MathKernel\" -mathlink'");
            }
            else
            {
                _kernelLink = MathLinkFactory.CreateKernelLink();
            }
            _kernelLink.WaitAndDiscardAnswer();
        }

        /// <summary>
        /// Has the Mathematica Kernel evaluate a string, formatted to include the provided arguments
        /// </summary>
        /// <param name="s"></param>
        /// <param name="args"></param>
        /// <returns></returns>
        public static Expr Eval(String s, params object[] args)
        {
            string sf;
            if (args ==null || !args.Any())
            {
                sf = s;
            }
            else
            {
                sf = String.Format(s, args);
            }
            Kernel.Evaluate(sf);
            Kernel.WaitForAnswer();
            var e = Kernel.GetExpr();
            return e;
        }

        /// <summary>
        /// Computes a function with a sequence of arguments
        /// </summary>
        /// <param name="functionName"></param>
        /// <param name="args"></param>
        /// <returns></returns>
        public static Expr EvalFunction(String functionName, IEnumerable<Expr> args)
        {
            return Eval("{0}[{1}]", functionName, String.Join(",", args));
        }

        public static bool EvalBool(String s, params object[] args)
        {
            string sf;
            if (args == null || !args.Any())
            {
                sf = s;
            }
            else
            {
                sf = String.Format(s, args);
            }
            Kernel.Evaluate(sf);
            Kernel.WaitForAnswer();
            var e = Kernel.GetBoolean();
            return e;
        }
    }

    public static class MSingleExtensions
    {
        public static int CompareTo(this Expr e0, Expr e1 = null)
        {
            if (e1 == null)
            {
                e1 = "0".MsEvalWith();
            }
            if (MSingle.EvalBool("{0} > {1}", e0, e1))
            {
                return 1;
            }
            if (MSingle.EvalBool("{0} < {1}", e0, e1))
            {
                return -1;
            }
            if (MSingle.EvalBool("{0} == {1}", e0, e1))
            {
                return 0;
            }
            throw new Exception("These two expressions are not comparable");
        }

        /// <summary>
        /// Formats the string to include the arguments and evaluates it with the Mathematica kernel
        /// </summary>
        /// <param name="s"></param>
        /// <param name="args"></param>
        /// <returns></returns>
        public static Expr MsEvalWith(this String s, params object[] args)
        {
            return MSingle.Eval(s, args);
        }

        /// <summary>
        /// Evaluates the function with this string name and the provided arguments with Mathematica
        /// </summary>
        /// <param name="s"></param>
        /// <param name="args"></param>
        /// <returns></returns>
        public static Expr MsBracket(this String s, IEnumerable<Expr> args)
        {
            return MSingle.EvalFunction(s, args);
        }

        /// <summary>
        /// Evaluates the function with this string name and the provided argument with Mathematica
        /// </summary>
        /// <param name="s"></param>
        /// <param name="args"></param>
        /// <returns></returns>
        public static Expr MsBracket(this String s, Expr arg)
        {
            return s.MsBracket(new[]{arg});
        }

       /* This was creating a strange bug!!
        * 
        * 
        * 
        public static Expr MsBracket(this String s, params Expr[] args)
        {
            return s.MsBracket(args);
        }
        */
    }
}
