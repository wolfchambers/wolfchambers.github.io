﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wolfram.NETLink;

namespace PolyLink
{
    /// <summary>
    /// Holds a reference to a point in the form of a Mathematica expression
    /// </summary>
    public class PointRef : MathLinked
    {
        /// <summary>
        /// Mathematica expression that represents a point in space
        /// </summary>
        public Expr Expr { get; set; }

        /// <summary>
        /// Constructs a PointRef
        /// </summary>
        /// <param name="point">The point which the PointRef references</param>
        public PointRef(Expr point)
        {
            Expr = point;
        }

        public static PointRef PointFromInts(int x, int y, int z)
        {
            return new PointRef(("{{ {0}, {1}, {2} }}".MsEvalWith(x,y,z)));
        }

        public static Expr operator- (PointRef p1, PointRef p2)
        {
            return p1.ML["{0} - {1}"].Format(p1.Expr, p2.Expr).Eval();
        }

        public override string ToString()
        {
            return "ref:" + Expr.ToString();
        }


        //Static methods
        private static readonly Expr _origin = MSingle.Eval(@"{ 0, 0, 0}");
        private static readonly PointRef _originRef = new PointRef(Origin);
        private static readonly Expr _p100 = MSingle.Eval(@"{ 1, 0, 0}");
        private static readonly PointRef _ref100 = new PointRef(P100);
        private static readonly Expr _p010 = MSingle.Eval(@"{ 0, 1, 0}");
        private static readonly PointRef _ref010 = new PointRef(P010);
        
        /// <summary>
        /// For testing use
        /// </summary>
        public static Expr Origin
        {
            get { return _origin; }
        }

        /// <summary>
        /// For testing use
        /// </summary>
        public static PointRef OriginRef
        {
            get { return _originRef; }
        }

        /// <summary>
        /// For testing use
        /// </summary>
        public static Expr P100
        {
            get { return _p100; }
        }

        /// <summary>
        /// For testing use
        /// </summary>
        public static PointRef Ref100
        {
            get { return _ref100; }
        }

        /// <summary>
        /// For testing use
        /// </summary>
        public static Expr P010
        {
            get { return _p010; }
        }

        /// <summary>
        /// For testing use
        /// </summary>
        public static PointRef Ref010
        {
            get { return _ref010; }
        }

        public Expr Highlight
        {
            get { return ML["List[ {{ PointSize[Large], Orange, Point[{0}] }} ]"].Format(Expr).Eval(); }
        }

        public Expr TwoDForm
        {
            get
            {
                //consider caching this
                if ((bool) ML["{0} == 0"].Format(Expr.Part(3)).EvalObject())
                {
                    return ML["{0}[[1;;2]]"].Format(Expr).Eval();
                }
                else
                {
                    throw new InvalidOperationException();
                }
            }
        }

        public PointRef DeepClone
        {
            get
            {
                return new PointRef(Expr);
            }
        }

        public void Transform(Expr tf)
        {
            Expr = ML["{0}[{1}]"].Format(tf, Expr).Eval();
        }

        public static PointRef Constructor(Expr e)
        {
            return new PointRef(e);
        }
    }
}
