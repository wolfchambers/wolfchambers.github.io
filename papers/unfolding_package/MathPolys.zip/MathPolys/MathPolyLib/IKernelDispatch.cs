﻿using Wolfram.NETLink;

namespace PolyLink
{
    /// <summary>
    /// Interface for the KernelDispatch class
    /// </summary>
    public interface IKernelDispatch
    {
        IKernelLink Kernel { get; }
        IKernelOperation this[string s] { get; }
    }
}