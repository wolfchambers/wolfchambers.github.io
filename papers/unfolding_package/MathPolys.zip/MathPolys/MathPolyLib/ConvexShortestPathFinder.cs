﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wolfram.NETLink;

namespace Defunct
{/*

    public class ConvexShortestPathFinder : MathLinked
    {
        public Polyhedron Poly
        {
            get { return _poly; }
        }

        public HalfEdge StartHE
        {
            get { return _startHE; }
        }

        public PointRef StartPoint
        {
            get { return _startPoint; }
        }

        public Facet EndFacet
        {
            get { return _endFacet; }
        }

        public PointRef EndPoint
        {
            get { return _endPoint; }
        }

        public ConvexShortestPathFinder(Polyhedron poly, HalfEdge startHE, PointRef startPoint, Facet endFacet,
                                        PointRef endPoint)
        {
            _poly = poly;
            _startHE = startHE;
            _startPoint = startPoint;
            _endFacet = endFacet;
            _endPoint = endPoint;
            _leaderBoard = new Dictionary<PointRef, Tuple<Cone, Expr>>();
        }

        private readonly Dictionary<PointRef, Tuple<Cone, Expr>> _leaderBoard;
        private readonly Polyhedron _poly;
        private readonly HalfEdge _startHE;
        private readonly PointRef _startPoint;
        private readonly Facet _endFacet;
        private readonly PointRef _endPoint;

        public bool SeeIfConeHasShortestPath(Cone subject, Expr distance, PointRef vert)
        {
            var coneDistance = _leaderBoard[vert];
            if (distance.CompareTo(coneDistance.Item2) < 0)
            {
                if (coneDistance.Item1 != null)
                    coneDistance.Item1.Invalidate();
                _leaderBoard[vert] = new Tuple<Cone, Expr>(subject, distance);
                return true;
            }
            return false;
        }

        public Expr ComputeShortestPath()
        {
            Expr infinity = "Infinity".MsEvalWith();
            foreach (var point in Poly.HalfEdges.Select(he => he.Start))
            {
                _leaderBoard[point] = new Tuple<Cone, Expr>(null, infinity);
            }
            _leaderBoard[EndPoint] = new Tuple<Cone, Expr>(null, infinity);
            var startClone = StartHE.FacetRingClone;
            var anchorMatrix = startClone.AnchorMatrix;
            var anchorStartPoint = new PointRef("{0}[{1}]".MsEvalWith(anchorMatrix, StartPoint.Expr));
            startClone.Anchor();

            var queue = new Queue<Cone>();

            var pairedHEs = StartHE.HEsFromHere.NetZip(startClone.HEsFromHere,
                                                       (original, clone) =>
                                                       new Tuple<HalfEdge, HalfEdge>(original, clone))
                                                       .NetZip(new[]{"Alpha","Beta","Gamma"}, (t, s) =>
                                                            new Tuple<HalfEdge, HalfEdge, String>(t.Item1, t.Item2, s));

            foreach (var hePair in pairedHEs)
            {
                var originalHE = hePair.Item1;
                var cloneHE = hePair.Item2;
                var tag = hePair.Item3;

                var ssEpp = new EndPointPacket(anchorStartPoint, cloneHE.Start);
                var sourceToStart = ssEpp.AsVector;
                _leaderBoard[originalHE.Start] = new Tuple<Cone, Expr>(null, ssEpp.Magnitude);

                var sourceToEnd = (new EndPointPacket(anchorStartPoint, cloneHE.End)).AsVector;
                
                //TODO Find some way to start cones at neighbor facets for these cases
                if ((bool) ML["{0} == {1}"].Format(sourceToStart, "{0,0,0}").EvalObject())
                {
                    continue;
                }
                if ((bool)ML["{0} == {1}"].Format(sourceToEnd, "{0,0,0}").EvalObject())
                {
                    continue;
                }

                var rightAngle = "- VectorAngle[{0},{1}]".MsEvalWith(sourceToStart, sourceToEnd);
                var abs = VectorMath.SignedAngle("{1,0,0}".MsEvalWith(), sourceToEnd);

                var oppClone = originalHE.Opposite.FacetRingClone;
                oppClone.Opposite = originalHE;
                oppClone.Unfold();
                var transform = oppClone.AnchorMatrix;

                var source = "{0}[{1}]".MsEvalWith(transform, StartPoint.Expr);

                queue.Enqueue(new Cone(parent: null,
                    relativeAngleL:"0".MsEvalWith(),
                    relativeAngleR:rightAngle,
                    absoluteSourceToCorner:abs,
                    relativeSource:source, 
                    currentCrossedHalfEdge:originalHE.Opposite,
                    cspf: this)
                        {Tag = tag});

            }
            long loopNumber = 0;
            while (queue.Count > 0)
            {
                loopNumber++;
                if (loopNumber == 300)
                {
                    Console.WriteLine("a");
                }
                var cone = queue.Dequeue();

                if ((bool) ML["{0}[[3]] < -.0001 || {0}[[3]] > .0001"].Format(cone.RelativeSource).EvalObject())
                {
                    throw new Exception("Relative source is not on plane");
                }

                if (!cone.Valid)
                    continue;
                var splitCones = cone.TryExtend();
                if (!cone.Valid || cone.AtEndFacet)
                    continue;
                if (splitCones.Item1 != null)
                {
                    if ((bool)ML["{0} < {1}"]
                       .Format(cone.ApproxAperture, splitCones.Item1.ApproxAperture)
                       .EvalObject())
                            {
                                Console.WriteLine("Child larger than parent");
                            }
                    queue.Enqueue(splitCones.Item1);
                }
                if (splitCones.Item2 != null)
                {
                    if ((bool)ML["{0} < {1}"]
                       .Format(cone.ApproxAperture, splitCones.Item2.ApproxAperture)
                       .EvalObject())
                                        {
                                            Console.WriteLine("Child larger than parent");
                                        }
                    queue.Enqueue(splitCones.Item2);
                }
            }
            return _leaderBoard[EndPoint].Item1.TrueAngle;
        }
    }*/
}
