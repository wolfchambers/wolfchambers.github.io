﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MoreLinq;

namespace PolyLink
{
    /// <summary>
    /// Contains extension methods for no classes in particular.
    /// </summary>
    public static class GeneralExtensions
    {
        /// <summary>
        /// Formats the string with the provided argument list
        /// </summary>
        /// <param name="s">String to be formatted</param>
        /// <param name="args">The object array that contains zero or more objects to format</param>
        /// <returns></returns>
        public static string Fmt(this String s, params object[] args)
        {
            return String.Format(s, args);
        }

        /// <summary>
        /// Prints the contents of an IEnumerable mid-enumeration.
        /// </summary>
        /// <param name="selector">Lambda to select what gets printed.</param>
        /// <returns>The original IEnumerable. But this function also prints selector(o) for every object in the IEnumerable</returns>
        public static IEnumerable<T1> Print<T1>(this IEnumerable<T1> enumerable, Func<T1, string> selector)
        {
            foreach (var i in enumerable)
            {
                Console.WriteLine(selector(i));
                yield return i;
            }
        }


        /// <summary>
        /// Circularly pairs elements of the sequence such that a_n is paired with a_(n+1). Also pairs last with first
        /// </summary>
        public static IEnumerable<Tuple<T,T>> CirclularPairs<T>(this IEnumerable<T> list)
        {
            var prevItem = list.First();

            foreach (var item in list.Skip(1))
            {
                yield return new Tuple<T, T>(prevItem, item);
                prevItem = item;
            }
            yield return new Tuple<T, T>(list.Last(), list.First());
        }

        /// <summary>
        /// For size m, groups the sequence {a_1, a_2 ... a_n} into elements containing {a_k ... a_(k+m)}. Goes in a circular fashion so the last and first elements are grouped.
        /// </summary>
        /// <param name="size">The size of the groupings</param>
        /// <returns></returns>
        public static IEnumerable<T[]> CircularTuples<T>(this IEnumerable<T> list, int size)
        {
            var bakedList = list.ToList();

            foreach (var i in Enumerable.Range(0, bakedList.Count))
            {
                var array = new T[size];
                foreach (var j in Enumerable.Range(0, size))
                {
                    int index = i + j;
                    if (index >= bakedList.Count)
                    {
                        index -= bakedList.Count;
                    }
                    array[j] = bakedList[index];
                }
                yield return array;
            }
        }

        /// <summary>
        /// Returns true iff the object equals any of the parameters.
        /// </summary>
        public static bool EqualsAny<T>(this T source, params T[] list)
        {
            if (null == source) throw new ArgumentNullException("source");
            return list.Contains(source);
        }

        /// <summary>
        /// Allows the built-in implementation of Enumerable.Zip to be called as an Extension Method, even when MoreLinq is being used.
        /// </summary>
        public static IEnumerable<TResult> NetZip<TFirst, TSecond, TResult>
            (this IEnumerable<TFirst> first, IEnumerable<TSecond> second, Func<TFirst, TSecond, TResult> resultSelector)
        {
            return Enumerable.Zip(first, second, resultSelector);
        }

        /// <summary>
        /// Converts an IEnumerable to a Hashset.
        /// </summary>
        public static HashSet<T> ToHashSet<T>(this IEnumerable<T> source)
        {
            return new HashSet<T>(source);
        }

        /// <summary>
        /// Allows the Count of an IEnumerable to be printed mid-enumeration/
        /// </summary>
        /// <param name="enumerableName">Name for the IEnumerable</param>
        /// <returns>The original IEnumerable</returns>
        public static IEnumerable<T> PrintCount<T>(this IEnumerable<T> source, string enumerableName)
        {
            var l = source.ToList();
            Console.WriteLine(enumerableName + " has " + l.Count + " members");
            return l;
        }
    }
}
