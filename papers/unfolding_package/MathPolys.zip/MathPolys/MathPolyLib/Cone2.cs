﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wolfram.NETLink;

namespace Defunct
{
    /*public class Cone : MathLinked
    {
        private bool _valid;

        private readonly Cone _parent;
        private Cone _left;
        private Cone _right;
        private readonly Expr _relativeSource;
        private readonly Expr _relativeAngleL;
        private readonly Expr _relativeAngleR;
        private readonly Expr _absoluteSourceToCorner;
        private readonly ConvexShortestPathFinder _cspf;
        private readonly Expr _anchorMatrix;

        private readonly HalfEdge _currentCrossedHalfEdge;
        private readonly HalfEdge _workingHECopy;

        public string Tag { get; set; }
        public Facet CurrentFacet
        {
            get { return _currentCrossedHalfEdge.Facet; }
        }
        public string CurrentFacetTag
        {
            get { return _currentCrossedHalfEdge.Facet.Tag; }
        }

        /// <summary>
        /// Constructs the cone. Note to self: Always used named parameters when using this constructor
        /// </summary>
        /// <param name="parent"></param>
        /// <param name="relativeAngleL"></param>
        /// <param name="relativeAngleR"></param>
        /// <param name="absoluteSourceToCorner"></param>
        /// <param name="relativeSource"></param>
        /// <param name="currentCrossedHalfEdge"></param>
        /// <param name="cspf"></param>
        public Cone(Cone parent, Expr relativeAngleL, Expr relativeAngleR,
            Expr absoluteSourceToCorner, Expr relativeSource,
            HalfEdge currentCrossedHalfEdge,
            ConvexShortestPathFinder cspf)
        {
            _parent = parent;
            _relativeAngleL = relativeAngleL;
            _relativeAngleR = relativeAngleR;
            _relativeSource = relativeSource;
            _currentCrossedHalfEdge = currentCrossedHalfEdge;
            _cspf = cspf;
            _absoluteSourceToCorner = absoluteSourceToCorner;
            _workingHECopy = _currentCrossedHalfEdge.FacetRingClone;
            _valid = true;
            _anchorMatrix = _workingHECopy.AnchorMatrix;

            _workingHECopy.Anchor();
        }

        public Cone Parent
        {
            get { return _parent; }
        }

        public Cone Left
        {
            get { return _left; }
        }

        public Cone Right
        {
            get { return _right; }
        }

        public bool Valid
        {
            get { return _valid; }
        }

        public void Invalidate()
        {
            if (Left != null)
            {
                Left.Invalidate();
            }
            if (Right != null)
            {
                Right.Invalidate();
            }
            _valid = false;
        }

        public Tuple<Cone, Cone> TryExtend()
        {
            switch (CheckIfShortestPath())
            {
                case ShortestPathResult.Shortest:
                    return new Tuple<Cone, Cone>(null, null);
                case ShortestPathResult.NotShortest:
                    Invalidate(); return new Tuple<Cone, Cone>(null, null);
                case ShortestPathResult.NotViable:
                    break;
                default:
                    throw new ArgumentOutOfRangeException();
            }

            var oppositeVertex = _currentCrossedHalfEdge.Next.End;
            
            var sourceToOppEpp = (new EndPointPacket(new PointRef(RelativeSource), TransformOppositeVertex));
            var sourceToOpp = sourceToOppEpp.AsVector;

            //TODO originToSource might be the opposite of what value we need in some uses. :/ :help:
            var originToSource = ML["- {0}"].Format(RelativeSource).Eval();
            
            var splitAngle = SignedAngle(originToSource, sourceToOpp);

            var lCompare = _relativeAngleL.CompareTo(splitAngle);
            var rCompare = _relativeAngleR.CompareTo(splitAngle);

            if (rCompare > lCompare)
            {
                throw new Exception("Right angle is left of left angle");
            }
            if (lCompare == 0 || lCompare != rCompare)
            {
                if (!_cspf.SeeIfConeHasShortestPath(this, sourceToOppEpp.Magnitude, oppositeVertex))
                {
                    Invalidate();
                    return new Tuple<Cone, Cone>(null, null);
                }
            }
            //TODO the angles need to be absolute, not relative. Otherwise this whole thing is useless!
            //I shouldn't be using the split angle all the time, some times it is outside of the bounds of angleL and angleR
            if (lCompare.EqualsAny(0, 1))
            {
                var leftHalfEdge = _currentCrossedHalfEdge.Prev.Opposite;

                var rightAngle = ML["Max"].Bracket(splitAngle, _relativeAngleR).Eval();

                _left = new Cone(parent: this,
                    relativeSource: TransformSourceLeft,
                    currentCrossedHalfEdge: leftHalfEdge,
                    relativeAngleL: _relativeAngleL,
                    relativeAngleR: rightAngle,
                    absoluteSourceToCorner: _absoluteSourceToCorner,
                    cspf: _cspf)
                    {Tag = Tag + " Left"};
            }
            if (rCompare.EqualsAny(0, -1))
            {
                var newAbsolute = ML["{0} + {1}"].Format(_absoluteSourceToCorner, splitAngle).Eval();


                var rightHalfEdge = _currentCrossedHalfEdge.Next.Opposite;

                var leftAngle = ML["Min"].Bracket(
                    ML["{0}-{1}"].Format(_relativeAngleL,splitAngle).Eval(),
                    "0").Eval();

                Expr rightAngle = ML["{0} - {1}"].Format(_relativeAngleR, splitAngle).Eval();

                _right = new Cone(parent: this,
                    relativeSource: TransformSourceRight,
                    currentCrossedHalfEdge: rightHalfEdge,
                    relativeAngleL: leftAngle,
                    relativeAngleR: rightAngle,
                    absoluteSourceToCorner: newAbsolute,
                    cspf: _cspf)
                    {Tag = Tag + " Right"};
            }
            return new Tuple<Cone, Cone>(Left, Right);
        }

        private enum ShortestPathResult
        {
            Shortest,
            NotShortest,
            NotViable
        }

        private ShortestPathResult CheckIfShortestPath()
        {
            var originToSource = ML["- {0}"].Format(RelativeSource).Eval();

            //TODO the cone might not be able to reach the endpoint, even if it reaches the facet.
            if (AtEndFacet)
            {
                var relativeEndPoint = "{0}[{1}]".MsEvalWith(_anchorMatrix, _cspf.EndPoint.Expr);
                var sourceToEnd = new EndPointPacket((new PointRef(RelativeSource)), new PointRef(relativeEndPoint));
                if (_cspf.SeeIfConeHasShortestPath(this, sourceToEnd.Magnitude, _cspf.EndPoint))
                {
                    var angleToEnd = SignedAngle(originToSource, sourceToEnd.AsVector);
                    TrueAngle = "{0} + {1}".MsEvalWith(_absoluteSourceToCorner, angleToEnd);
                    return ShortestPathResult.Shortest;
                }
                return ShortestPathResult.NotShortest;
            }
            return ShortestPathResult.NotViable;
        }

        private PointRef TransformOppositeVertex
        {
            get
            {
                return _workingHECopy.Next.End;
            }
        }

        /// <summary>
        /// Transforms the relative source point for the left cone
        /// </summary>
        private Expr TransformSourceLeft
        {
            get
            {
                var lCopy = _currentCrossedHalfEdge.Prev.Opposite.FacetRingClone;
                lCopy.Opposite = _workingHECopy.Prev;
                lCopy.Unfold();
                var transform = lCopy.AnchorMatrix;
                return ML["{0}[{1}]"].Format(transform, RelativeSource).Eval();
            }
        }

        /// <summary>
        /// Transforms the relative source point for the right cone.
        /// </summary>
        private Expr TransformSourceRight
        {
            //TODO use AnchorMatrix instead perhaps
            get
            {
                var rCopy = _currentCrossedHalfEdge.Next.Opposite.FacetRingClone;
                rCopy.Opposite = _workingHECopy.Next;
                rCopy.Unfold();
                var transform = rCopy.AnchorMatrix;

                return ML["{0}[{1}]"].Format(transform, RelativeSource).Eval();
            }
        }

        public Expr TrueAngle { get; set; }

        public ConvexShortestPathFinder Cspf
        {
            get { return _cspf; }
        }

        private Expr SignedAngle(Expr vector1, Expr vector2)
        {
            return VectorMath.SignedAngle(vector1, vector2);
        }

        public Expr ApproxAperture
        {
            get { return ML["N[Mod[({0} - {1}), 2*Pi]]"].Format(_relativeAngleL, _relativeAngleR).Eval(); }
        }

        public bool AtEndFacet
        {
            get { return _cspf.EndFacet.HalfEdges.Contains(_currentCrossedHalfEdge); }
        }

        public Expr ApproxLength
        {
            get
            {
                var mag = (new EndPointPacket(new PointRef(RelativeSource), PointRef.OriginRef)).Magnitude;
                return ML["N"].Bracket(mag).Eval();
            }
        }

        public Expr RelativeSource
        {
            get { return _relativeSource; }
        }
    }

    public static class VectorMath
    {
        public static Expr SignedAngle(Expr vector1, Expr vector2)
        {
            return "Sign[Dot[{{ -{0}[[2]], {0}[[1]], 0 }}, {1}]]*ArcCos[Dot[Normalize[{0}], Normalize[{1}]]]"
                .MsEvalWith(vector1, vector2);
        }
    }*/
}
