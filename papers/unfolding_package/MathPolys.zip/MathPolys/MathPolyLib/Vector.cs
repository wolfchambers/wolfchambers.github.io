﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wolfram.NETLink;

namespace PolyLink
{
    public struct Vector
    {
        private readonly Expr _expr;

        public Vector(Expr expr) : this()
        {
            _expr = expr;
        }

        public Expr Expr
        {
            get { return _expr; }
        }

        public static Vector FromPoints(Expr point1, Expr point2)
        {
            return new Vector(MSingle.Eval("{1} - {0}", point1, point2));
        }

        public Expr Length
        {
            get { return "Sqrt".MsBracket("Dot".MsBracket(new[] {_expr, _expr})); }
        }
    }
}
