﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wolfram.NETLink;

namespace PolyLink
{
    /// <summary>
    /// The building blocks of a geometric model, a HalfEdge consists of a reference to a start and end point, and links to
    /// the counter-clockwise Next, Previous, and Oppostie HalfEdges.
    /// </summary>
    public class HalfEdge : MathLinked
    {

        /// <summary>
        /// Reference to the Facet that owns this HalfEdge.
        /// </summary>
        public Facet Facet { get; set; }

        /// <summary>
        /// A string used to identify this HalfEdge. Not used in code, but useful for debugging.
        /// </summary>
        public string Tag
        {
            get { return Facet.Tag; }
        }

        /// <summary>
        /// Exports the EndpointPacket for this HalfEdge
        /// </summary>
        public EndPointPacket EndPointPacket
        {
            get
            {
                return new EndPointPacket(Start, End);
            }
        }

        /// <summary>
        /// Exports the OppositeEndpointPacket for this HalfEdge
        /// </summary>
        public EndPointPacket OppositesEndPointPacket
        {
            get
            {
                return EndPointPacket.Opposite;
            }
        }

        /// <summary>
        /// Reference to the start point of this HalfEdge.
        /// </summary>
        public PointRef Start
        {
            get { return _start; }
            set { _start = value; }
        }

        /// <summary>
        /// Reference to the end point of this HalfEdge.
        /// </summary>
        public PointRef End
        {
            get { return _end; }
            set { _end = value; }
        }

        protected PointRef _start;
        protected PointRef _end;

        protected HalfEdge _opposite;

        /// <summary>
        /// The HalfEdge which represnts the same edge but bounds a neighboring facet
        /// </summary>
        public HalfEdge Opposite
        {
            get { return _opposite; }
            set
            {
                _opposite = value;
            }
        }

        protected HalfEdge _next;
        protected HalfEdge _prev;

        /// <summary>
        /// The next HalfEdge going counterclockwise
        /// </summary>
        public HalfEdge Next
        {
            get { return _next; }
        }

        /// <summary>
        /// The previous Halfedge
        /// </summary>
        public HalfEdge Prev
        {
            get { return _prev; }
        }

        /// <summary>
        /// Enumerates the halfedges around the facet that this binds
        /// </summary>
        public IEnumerable<HalfEdge> HEsFromHere
        {
            get
            {
                yield return this;
                var he = this.Next;
                while (he != this)
                {
                    yield return he;
                    he = he.Next;
                }
            }
        }

        /// <summary>
        /// Enumerates the halfedges around the facet that this binds, but in reverse order.
        /// </summary>
        public IEnumerable<HalfEdge> HEsFromHereReversed
        {
            get
            {
                yield return this;
                var he = this.Prev;
                while (he != this)
                {
                    yield return he;
                    he = he.Prev;
                }
            }
        }

        /// <summary>
        /// Gives the displacement vector from Start to End
        /// </summary>
        public Expr AsVectorExpr
        {
            get { return EndPointPacket.AsVector; }
        }

        /// <summary>
        /// Gives the displacement vector from Start to End, as a Vector object.
        /// </summary>
        public Vector AsVector
        {
            get {return new Vector(this.AsVectorExpr);}
        }

        /// <summary>
        /// Gives the plane containing this HalfEdge
        /// </summary>
        public Plane Plane
        {
            get
            {
                Expr point = Start.Expr;
                Expr normal = ML["Normalize[Cross[{0},{1}]]"].Format(this.AsVectorExpr, Next.AsVectorExpr).FullSimplify().Eval();
                return new Plane(point, normal);
            }
        }

        /// <summary>
        /// Dots this halfedge's facet with the facet's neighbor along this halfedge.
        /// </summary>
        public Expr DotOpposite
        {
            get { return ML["Dot[{0},{1}]"].Format(this.Plane.Normal, Opposite.Plane.Normal).Eval(); }
        }

        /// <summary>
        /// Create a pair of Half-Edges following this one, which go from this's End to p, and back again
        /// </summary>
        /// <param name="p"></param>
        public HalfEdge[] DetourToVertex(PointRef p)
        {
            var ret = new HalfEdge[2];
            var outHE = new HalfEdge(End, p)
                {
                    Facet = Facet
                };
            var backHE = new HalfEdge(p, End)
                {
                    Facet = Facet
                };
            outHE.Opposite = backHE;
            backHE.Opposite = outHE;

            var oldNext = _next;
            _next = outHE;
            outHE._prev = this;
            outHE._next = backHE;
            backHE._prev = outHE;
            backHE._next = oldNext;

            ret[0] = outHE;
            ret[1] = backHE;
            return ret;
        }

        /// <summary>
        /// Links a HalfEdge to this one and saves references to possibly unlinked HalfEdges 
        /// </summary>
        /// <param name="he">HalfEdge which will become the new next</param>
        /// <returns>Small Dictionary. Value[this] is the old Next of this. Value[he] is the old Prev of he.</returns>
        public Dictionary<HalfEdge, HalfEdge> LinkNext(HalfEdge he)
        {
            var d = new Dictionary<HalfEdge, HalfEdge>();
            d[this] = Next;
            d[he] = he.Prev;
            _next = he;
            he._prev = this;
            return d;
        }

        /// <summary>
        /// Returns true iff opposite is null
        /// </summary>
        public bool OppIsNull
        {
            get { return Opposite == null; }
        }

        /// <summary>
        /// Removes this HalfEdge and joins two neighboring facets
        /// </summary>
        public void MergeAcross()
        {
            var prev = Prev;
            prev.LinkNext(Opposite.Next);
            Opposite.Prev.LinkNext(Next);
            Opposite.Facet.Head = null;
            foreach (var halfEdge in prev.HEsFromHere)
            {
                halfEdge.Facet = Facet;
            }
        }

        public override string ToString()
        {
            return String.Format("[{0} to {1}]", Start, End);
        }

        /// <summary>
        /// Designates that this HalfEdge should break the cycle if the CycleBoutEndPoint property is called.
        /// Useful for if a HalfEdge is a working copy that references a real HalfEdge.
        /// </summary>
        public bool DontCycle { get; set; }

        /// <summary>
        /// Enumerates all HalfEdges which have End as their end point
        /// </summary>
        public IEnumerable<HalfEdge> CycleAboutEndPoint
        {
            get
            {
                if (DontCycle)
                {
                    yield break;
                }

                yield return this;
                var he = this.Next.Opposite;
                while (he != this)
                {
                    yield return he;
                    he = he.Next.Opposite;
                }
            }
        }

        /// <summary>
        /// Turns the dot product of this and next
        /// </summary>
        public Expr DotNext
        {
            get { return ML["Dot"].Bracket(this.AsVectorExpr, this.Next.EndPointPacket.Opposite.AsVector).Eval(); }
        }

        /// <summary>
        /// Angle between this and next
        /// </summary>
        public Expr AngleToNext
        {
            get
            {
                return ML["ArcCos[{0}] / ({1} * {2})"].Format(this.DotNext, this.EndPointPacket.Magnitude,
                                                            this.Next.EndPointPacket.Magnitude).Eval();
            }
        }

        /// <summary>
        /// Sum of all angles around this vertex
        /// </summary>
        public Expr SumAngles
        {
            get
            {
                return this.CycleAboutEndPoint.Select(he => he.AngleToNext).Aggregate((a1, a2) => ML["{0} + {1}"].Format(a1,a2).Eval());
            }
        }

        /// <summary>
        /// Curvature of this vertex
        /// </summary>
        public Expr Curvature
        {
            get { return ML["2*Pi - {0}"].Format(SumAngles).Eval(); }
        }

        /// <summary>
        /// A graphics primitive that indicates this HalfEdge with a Thick Red Arrow.
        /// </summary>
        public Expr Highlight
        {
            get { return ML["List[ {{ Thick, Red, Arrow[ {{ {0},{1} }} ] }} ]"].Format(Start.Expr, End.Expr).Eval(); }
        }

        //Static methods

        private static readonly HalfEdge littleLine = new HalfEdge(PointRef.OriginRef, PointRef.Ref100);
        private static readonly HalfEdge line2 = new HalfEdge(PointRef.Ref100, PointRef.Ref010);
        private static readonly HalfEdge line3 = new HalfEdge(PointRef.Ref010, PointRef.OriginRef);

        /// <summary>
        /// For testing
        /// </summary>
        public static HalfEdge LittleLine
        {
            get { return littleLine; }
        }

        /// <summary>
        /// For testing
        /// </summary>
        public static HalfEdge Facetable
        {
            get
            {
                if (LittleLine.Next == null)
                {
                    LittleLine.LinkNext(line2);
                    line2.LinkNext(line3);
                    line3.LinkNext(LittleLine);
                }
                return LittleLine;
            }
        }

        /// <summary>
        /// Graphics Primitive to visualize the Normal of this HalfEdge.
        /// </summary>
        public Expr NormalGraphics
        {
            get { return ML["List[ {{Purple, Arrow[ {{ {0}, {0} + {1} }} ] }} ]"].Format(End.Expr, Plane.Normal).Eval(); }
        }
        //End section

        public HalfEdge(PointRef start, PointRef end)
        {
            _start = start;
            _end = end;
            DontCycle = false;
        }

        /// <summary>
        /// Returns true iff this HalfEdge's opposite is not made of the same point reference as this.
        /// </summary>
        public bool Torn
        {
            get
            {
                return (Opposite == null)
                       || (Opposite.Start != End)
                       || (Opposite.End != Start);
            }
        }

        /// <summary>
        /// Moves the entire Facet so that it is coplanar with the neighbor opposite this HalfEdge.
        /// </summary>
        public void Unfold(IEnumerable<PointRef> stowaways = null, IEnumerable<HalfEdge> stowawayHalfEdges = null)
        {

            if (stowaways == null)
            {
                stowaways = Enumerable.Empty<PointRef>();
            }
            if (stowawayHalfEdges == null)
            {
                stowawayHalfEdges = Enumerable.Empty<HalfEdge>();
            }

            var transVect = Vector.FromPoints(this.Start.Expr, Opposite.End.Expr);
            var translation = ML["TranslationTransform"].Bracket(transVect.Expr).Eval();
            TransformFacet(translation);
            foreach (var stowaway in stowaways)
            {
                stowaway.Transform(translation);
            }
            foreach (var halfedge in stowawayHalfEdges)
            {
                halfedge.Transform(translation,
                    includeStart: !halfedge.Start.EqualsAny(Start,End),
                    includeEnd: !halfedge.End.EqualsAny(Start,End));
            }

            var rotation1 = ML["RotationTransform"].Bracket(
                        ML["List"].Bracket(
                                this.Plane.Normal,
                                Opposite.Plane.Normal
                            ).Eval(),
                            Opposite.End.Expr
                    ).Eval();
            TransformFacet(rotation1);
            foreach (var stowaway in stowaways)
            {
                stowaway.Transform(rotation1);
            }
            foreach (var halfedge in stowawayHalfEdges)
            {
                halfedge.Transform(rotation1,
                    includeStart: !halfedge.Start.EqualsAny(Start, End),
                    includeEnd: !halfedge.End.EqualsAny(Start, End));
            }

            var rotation2 = ML["RotationTransform"].Bracket(
                ML["List"].Bracket(
                        this.AsVectorExpr,
                        ML["-1 * {0}"].Format(Opposite.AsVectorExpr).Eval()
                    ).Eval(),
                    Opposite.End.Expr
                ).Eval();
            TransformFacet(rotation2);
            foreach (var stowaway in stowaways)
            {
                stowaway.Transform(rotation2);
            }
            foreach (var halfedge in stowawayHalfEdges)
            {
                halfedge.Transform(rotation2,
                    includeStart: !halfedge.Start.EqualsAny(Start, End),
                    includeEnd: !halfedge.End.EqualsAny(Start, End));
            }

            //This 'snapping' code is part of correct behavior, but we sometimes
            //comment it out to check our transforms.
            
            Start = Opposite.End;
            End = Opposite.Start;
            Prev.End = Start;
            Next.Start = End;
        }

        /// <summary>
        /// Transforms every HalfEdge in the facet by a matrix.
        /// </summary>
        /// <param name="matrix">matrix to transform this facet</param>
        public void TransformFacet(Expr matrix)
        {
            //For every HalfEdge other than myself
            foreach (var halfEdge in HEsFromHere)
            {
                halfEdge.Transform(matrix);
            }

            foreach (var halfEdge in HEsFromHere)
            {
                halfEdge.Next.Start = halfEdge.End;
            }
        }

        /// <summary>
        /// Transforms the facet by translating it {0,0,0}. In other words, doesn't move the facet at all.
        /// </summary>
        public void UselessTransform()
        {
            var m = ML["TranslationTransform"].Bracket("{0,0,0}").Eval();
            TransformFacet(m);
        }

        /// <summary>
        /// Moves the facet so that this HalfEdge's start point is at the origin, the EndPoint is in the direction {1,0,0},
        /// and the whole facet is in the xy plane.
        /// </summary>
        public void Anchor(IEnumerable<PointRef> stowaways)
        {
            if (stowaways == null)
            {
                stowaways = Enumerable.Empty<PointRef>();
            }

            var transVec = new EndPointPacket(this.Start, PointRef.OriginRef).AsVector;
            var translation = ML["TranslationTransform"].Bracket(transVec).Eval();
            TransformFacet(translation);
            foreach (var stowaway in stowaways)
            {
                stowaway.Transform(translation);
            }


            var rotation1 = ML["RotationTransform"].Bracket(
                        ML["List"].Bracket(
                                this.Plane.Normal,
                                ML["{0,0,1}"].Eval()
                            ).Eval(),
                            PointRef.Origin
                    ).Eval();
            TransformFacet(rotation1);
            foreach (var stowaway in stowaways)
            {
                stowaway.Transform(rotation1);
            }

            var rotation2 = ML["RotationTransform"].Bracket(
                    ML["List"].Bracket(
                            this.AsVectorExpr,
                            ML["{1,0,0}"].Eval()
                        ).Eval()
                ).Eval();
            TransformFacet(rotation2);
            foreach (var stowaway in stowaways)
            {
                stowaway.Transform(rotation2);
            }

            var rotation3 = ML["RotationTransform"].Bracket(
                    ML["List"].Bracket(
                            this.Plane.Normal,
                            ML["{0,0,1}"].Eval()
                        ).Eval(),
                        PointRef.Origin
                ).Eval();
            TransformFacet(rotation3);
            foreach (var stowaway in stowaways)
            {
                stowaway.Transform(rotation3);
            }
        }
        /// <summary>
        /// Transforms just this HalfEdge.
        /// </summary>
        /// <param name="transform">A transform matrix by which to transform the start and end points of this HalfEdge.</param>
        public void Transform(Expr transform, bool includeStart = true, bool includeEnd = true)
        {

            if (includeStart)
            {
                Start = new PointRef(
                    ML["{0}[{1}]"].Format(transform, Start.Expr).Eval());
            }
            if (includeEnd)
            {
                End = new PointRef(
                    ML["{0}[{1}]"].Format(transform, End.Expr).Eval());
            }
        }

        /// <summary>
        /// Give a graphical representation of the link between this HalfEdge and its opposite.
        /// </summary>
        public Expr Graphics
        {
            get
            {
                if (Torn)
                {
                    return ML["List[{{ Dashed, Arrow[ {{ {0}, {1} }}] }}]"].Format(Start.Expr, Opposite.End.Expr).Eval();
                }
                return null;
            }
        }

        /// <summary>
        /// Translates this HalfEdge in the opposite direction as the vector v.
        /// </summary>
        /// <param name="v"></param>
        public void NegativeTranslate(Vector v)
        {
            var translation = ML["TranslationTransform[-{0}]"].Format(v.Expr).Eval();
            TransformFacet(translation);
        }

        /// <summary>
        /// Clones all the HalfEdges in this HalfEdge's facet, then gives each HalfEdge a link to the (original) opposite.
        /// </summary>
        public HalfEdge FacetCloneWithOriginalOpposites
        {
            get {
                var clone = FacetRingClone;
                var clonePairs = HEsFromHere
                    .NetZip(clone.HEsFromHere,
                         (o, c) => new WorkingCopy<HalfEdge>(o,c));
                foreach (var cp in clonePairs)
                {
                    cp.Copy.Facet = cp.Original.Facet;
                    cp.Copy.Opposite = cp.Original.Opposite;
                }
                return clone;
            }
        }

        /// <summary>
        /// Clones all the HalfEdges in this HalfEdge's facet
        /// </summary>
        public HalfEdge FacetRingClone
        {
            get
            {
                var cloneRing = HEsFromHere
                    .Select(he => he.ShallowClone).Skip(1);
                var prev = ShallowClone;
                var myClone = prev;

                foreach (var he in cloneRing.Concat(new[] { myClone }))
                {
                    he.Start = he.Start.DeepClone;
                    prev.End = he.Start;
                    prev.LinkNext(he);
                    prev = he;
                }

                return myClone;
            }
        }

        /// <summary>
        /// Creates a "Shallow Clone" of this HalfEdge, using the original Start, End, Next, and Prev. Opposite is set to null.
        /// </summary>
        protected HalfEdge ShallowClone
        {
            get
            {
                var r=  new HalfEdge(Start, End)
                    {
                        _next = Next,
                        _prev = Prev,
                        _opposite = null,
                    };
                r.DontCycle = true;
                return r;
            }
        }

        /// <summary>
        /// Gives the midpoint between Start and End.
        /// </summary>
        public Expr Midpoint
        {
            get { return ML["Mean"].Bracket(
                ML["List"].Bracket(Start.Expr, End.Expr).Eval()).Eval(); }
        }

        /// <summary>
        /// Returns a Mathematica graphics primitive for an inset label above this HalfEdge.
        /// </summary>
        /// <param name="i">The number for the label</param>
        /// <returns></returns>
        public Expr Label(int i)
        {
            var labelPoint = ML["{0} + .05*{1}"].Format(Midpoint, Plane.Normal).Eval();
            return ML["Inset"].Bracket(i, labelPoint, "BaseStyle -> {Darker[Blue], Italic}").Eval();
        }


        public void MoveStartPoint(Expr p)
        {
            Start.Expr = p;
        }

        public Facet ForceNewFacet
        {
            get
            {
                return new Facet(this);
            }
        }

        /// <summary>
        /// Creates a list of all connected half-edges in Breadth-First order, starting from here.
        /// </summary>
        /// <param name="includeTorn"></param>
        /// <returns></returns>
        public IEnumerable<HalfEdge> BreadthFirstGrab(bool includeTorn = false)
        {
            var dontGrab = new HashSet<HalfEdge>();
            var queue = new Queue<HalfEdge>();
            var grab = new List<HalfEdge>();

            queue.Enqueue(this);
            dontGrab.UnionWith(this.Opposite.HEsFromHere.ToHashSet());

            while (queue.Count > 0)
            {
                var he = queue.Dequeue();
                if (dontGrab.Contains(he))
                    continue;

                grab.Add(he);
                dontGrab.UnionWith(he.HEsFromHere.ToHashSet());

                var opposites = he.HEsFromHere.Skip(1).Select(h => h.Opposite).ToList();
                var validOpps = opposites
                    .Where(h => !dontGrab.Contains(h))
                    .Where(h => includeTorn || !h.Torn).ToList();
                foreach (var halfedge in validOpps)
                {
                    queue.Enqueue(halfedge);
                }
            }
           
            return grab;
        }

        public IEnumerable<PointRef> StartPointsFromHere
        {
            get { return HEsFromHere.Select(he => he.Start); }
        }
        
        /// <summary>
        /// Unfolds along a halfedge and moves whole sections of the polyhedron with it.
        /// </summary>
        /// <param name="p"></param>
        public void CascadingUnfold(Polyhedron p)
        {
            var facetHesTorn = HEsFromHere.Select(he => he.Torn).ToList();

            var hes = BreadthFirstGrabAll();
            Unfold(null, hes);
            p.FusePoints();
            //Prev.End = Start;
            //Next.Start = End;

            var facetHes_facetHesTorn = HEsFromHere.NetZip(facetHesTorn, (he, b) => new Tuple<HalfEdge,bool>(he,b));
            foreach (var tuple in facetHes_facetHesTorn)
            {
                HalfEdge h = tuple.Item1;
                bool wasTorn = tuple.Item2;

                if (!wasTorn)
                {
                    h.Start = h.Opposite.End;
                    h.End = h.Opposite.Start;
                }
            }
        }

        public IEnumerable<PointRef> BreadthFirstPoints()
        {
            return BreadthFirstGrab().Except(new[] {this}).SelectMany(he => he.StartPointsFromHere).Except(new[] {Start,End}).ToHashSet();
        }

        public IEnumerable<HalfEdge> BreadthFirstGrabAll()
        {
            return BreadthFirstGrab().Except(new[] {this}).SelectMany(he => he.HEsFromHere).ToHashSet();
        }
    }
}
