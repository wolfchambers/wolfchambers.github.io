﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wolfram.NETLink;

namespace PolyLink
{
    public static class NetLinkExtensions
    {
        public static IEnumerable<Expr> Parts(this Expr e)
        {
            //Loop preparation
            int count = e.Length;

            return Enumerable.Range(1, count).Select(i => e[i]);
        }
    }
}
