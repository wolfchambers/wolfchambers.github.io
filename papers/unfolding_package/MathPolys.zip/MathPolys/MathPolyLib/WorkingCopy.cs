﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolyLink
{

    public struct WorkingCopy<T>
    {
        private readonly T _original;
        private readonly T _copy;

        public WorkingCopy(T original, T copy) : this()
        {
            _original = original;
            _copy = copy;
        }

        public T Original
        {
            get { return _original; }
        }

        public T Copy
        {
            get { return _copy; }
        }
    }

    public static class WorkingCopyExtension
    {
        public static WorkingCopy<T> WorkingCopy<T>(this T original, Func<T, T> cloner)
        {
            return new WorkingCopy<T>(original, cloner(original));
        }
    }
}
