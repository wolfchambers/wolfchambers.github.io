﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wolfram.NETLink;
using MoreLinq;

namespace PolyLink
{
    /// <summary>
    /// A polyhedron! It contains a list of facets.
    /// </summary>
    public class Polyhedron : MathLinked
    {
        public Polyhedron()
        {
            _facets = new List<Facet>();
        }

        private List<Facet> _facets; 

        public IEnumerable<Facet> Facets
        {
            get { _facets.RemoveAll(f => f.Head == null);
                return _facets;
            }
        }

        public Facet[] FacetArray
        {
            get { return Facets.ToArray(); }
        }

        public Expr Graphics
        {
            get
            {
                return ML["List"].Bracket(
                    ML["List"].Bracket(Facets.Select(f => f.Graphics)).Eval()
                    ).Eval();
            }
        }

        public IEnumerable<HalfEdge> HalfEdges
        {
            get { return Facets.SelectMany(f => f.HalfEdges); }
        }

        public void AddFacet(Facet f)
        {
            _facets.Add(f);
        }

        public void AddFacets(IEnumerable<Facet> facets)
        {
            _facets.AddRange(facets);
        }

        public void AddFacets(Facet[] facets)
        {
            _facets.AddRange(facets);
        }

        public IEnumerable<HalfEdge> OutOfOrderHalfEdges
        {
            get
            {
                return HalfEdges.Where(he => he.Next.Start != he.End);
            }
        }

        public Expr HalfEdgeGraphics
        {
            get
            {
                return ML["List"].Bracket(
                    ML["List"].Bracket(HalfEdges.Select(he => he.Graphics).Where(g => g != null)).Eval()
                    ).Eval();
            }
        }

        public IEnumerable<Facet[]> SlowDangerousIntersectionTest()
        {
            return (from f1 in _facets
                    from f2 in _facets
                        where (_facets.IndexOf(f1) > _facets.IndexOf(f2))
                        select new[] {f1, f2})
                        .Where(fp =>
                            fp[0].CheckIntersectSlow(fp[1]) ||
                            fp[1].CheckIntersectSlow(fp[0])
                            );
        }

        public IEnumerable<Facet[]> ConvexAssumingInteresectionTest()
        {
            if (!Facets.All(f => f.Convex))
            {
                throw new Exception("Only run this when all the facets are convex!");
            }

            return (from f1 in _facets
                    from f2 in _facets
                    where (_facets.IndexOf(f1) > _facets.IndexOf(f2))
                    select new[] { f1, f2 })
                        .Where(fp =>
                            fp[0].CheckIntersectSlow(fp[1]) ||
                            fp[1].CheckIntersectSlow(fp[0])
                            );
        }

        public void Triangulate()
        {
            var newFacets = Facets.SelectMany(f => f.Triangulate()).ToList();
            _facets.AddRange(newFacets);
        }

        public void MakeNumerical()
        {
            var prs = HalfEdges.Select(he => he.Start).Distinct();
            foreach (var pointRef in prs)
            {
                pointRef.Expr = ML["N"].Bracket(pointRef.Expr).Eval();
            }
        }

        public Polyhedron CloneAll()
        {

            var clonePoly = new Polyhedron();

            var cloneDex = new Dictionary<HalfEdge, HalfEdge>();

            foreach (var facet in Facets)
            {
                var f = facet.CloneWithAllHalfEdgesCloned;

                var originalClonePairs = facet.HalfEdges
                                              .NetZip(f.HalfEdges,
                                              (orignal, clone) => new KeyValuePair<HalfEdge, HalfEdge>(orignal, clone));

                foreach (var pair in originalClonePairs)
                {
                    cloneDex.Add(pair.Key, pair.Value);
                }

                clonePoly.AddFacet(f);
            }

            foreach (var kvp in cloneDex)
            {
                var oppositeClone = cloneDex[kvp.Key.Opposite];
                kvp.Value.Opposite = oppositeClone;
            }

            return clonePoly;

        }

        public void ForceHalfEdgesToReferenceFacets()
        {
            foreach (var f in Facets)
            {
                f.ForceHalfEdgesToReferenceThis();
            }
        }


        public Expr NormalGraphics
        {
            get { return Labelize((i, f) => f.NormalGraphics); }
        }

        public Expr Labels
        {
            get { return Labelize((i, f) => f.ClipLabel(i)); }
        }

        public Expr InsetLabels
        {
            get { return Labelize((i, f) => f.InsetLabel(i)); }
        }

        public void TagFacets()
        {
            var facetIndices = Enumerable.Range(1, int.MaxValue)
                .NetZip(Facets, (i, f) => new Tuple<int, Facet>(i,f));
            foreach (var fi in facetIndices)
            {
                fi.Item2.Tag = fi.Item1.ToString();
            }

        }

        public Expr Labelize(Func<int, Facet, Expr> labelizer)
        {
            var labels = Enumerable.Range(1, int.MaxValue).NetZip(Facets, labelizer);
            return
                ML["List"].Bracket
                (
                    ML["List"]
                        .Bracket(labels)
                        .Eval()
                ).Eval();
        }

        public Facet PickFacet(int n)
        {
            return _facets[n-1];
        }

        public Expr AllLabels
        {
            get
            {
                return Labelize((i, f) => 
                    ML["List"].Bracket
                        (
                            ML["List"]
                                .Bracket(f.InsetLabel(i), f.HELabels)
                                .Eval()
                        ).Eval());
            }
        }

        public HalfEdge PickHalfEdge(int fNumber, int hNumber)
        {
            return PickFacet(fNumber).PickHalfEdge(hNumber);
        }

        /// <summary>
        /// Forces HalfEdges to share PointRefs when their PointRefs already refer the same point in space.
        /// </summary>
        public void FusePoints()
        {

            var masters = new Dictionary<string, PointRef>();

            foreach (var halfEdge in HalfEdges)
            {

                if (!masters.ContainsKey(halfEdge.Start.Expr.ToString()))
                {
                    masters[halfEdge.Start.Expr.ToString()] = halfEdge.Start;
                }
                if (!masters.ContainsKey(halfEdge.End.Expr.ToString()))
                {
                    masters[halfEdge.End.Expr.ToString()] = halfEdge.End;
                }
            }

            foreach (var halfEdge in HalfEdges)
            {
                halfEdge.Start = masters[halfEdge.Start.Expr.ToString()];
                halfEdge.End = masters[halfEdge.End.Expr.ToString()];
            }
        }

        public IEnumerable<HalfEdge> TornHalfEdges
        {
            get { return HalfEdges.Where(he => he.Torn); }
        }
    }
}
