﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wolfram.NETLink;

namespace PolyLink
{
    public static class PolyIO
    {
        public static Polyhedron PolyFromName(Expr name)
        {
            return PolyFromExpr((
                "{{" +
                "PolyhedronData[{0}][[1]][[1]]," +
                "Map[# - 1 &, PolyhedronData[{0}][[1]][[2]][[1]], {{2}}]" +
                "}}"
                    ).MsEvalWith(name));
        }
        
        //TODO HalfEdges appear to be going clockwise instead of counter-clockwise!! This could get really bad fast!!

        public static Polyhedron PolyFromExpr(Expr polyData)
        {
            var pointsExpr = polyData.Part(1);
            var facetsExpr = polyData.Part(2);

            //TODO: Verify that input is valid
            var pointList = pointsExpr.Parts().Select(e => new PointRef(e)).ToList();

            //Console.WriteLine("Point list is: {" + String.Join(",",pointList) + "}");

            var facetList = facetsExpr.Parts().Select(fe => FacetFromExpr(pointList, fe)).ToList();

            var poly = new Polyhedron();

            foreach (var facet in facetList)
            {
                poly.AddFacet(facet);
            }

            //Refer to "Connect opposite halfEdges"
            var halfEdges = facetList.SelectMany(f => f.HalfEdges).ToList();

            var dict = halfEdges.ToDictionary(halfEdge => halfEdge.EndPointPacket);

            foreach (var halfEdge in halfEdges)
            {
                halfEdge.Opposite = dict[halfEdge.OppositesEndPointPacket];
                halfEdge.Start = halfEdge.Opposite.End;
                halfEdge.End = halfEdge.Opposite.Start;
            }
            return poly;
        }

        public static Facet FacetFromExpr(IList<PointRef> points, Expr f)
        {
            var pointIndices = f.Parts()
                              .Select(p => (int) p.AsInt64()); //Convert to point indices

            //Console.WriteLine("Facet has point indices {" + String.Join(",", pointIndices) + "}");
            
            var halfEdges = pointIndices
                              .Select(i => points[i])//Get referenced points
                              .CircularTuples(2)
                              .Select(pair => new HalfEdge(pair[0], pair[1]))//Get point pairs (to represent half edges)
                              .ToList();

            //Console.WriteLine(String.Join("\n", halfEdges));
            //Console.WriteLine("-");

            foreach (var halfEdgePair in halfEdges.CircularTuples(2))
            {
                halfEdgePair[0].LinkNext(halfEdgePair[1]);
            }
            return new Facet(halfEdges.First());
        }

        public static Polyhedron TestTriangle
        {
            get
            {
                var tetrahedron = PolyFromName("\"Tetrahedron\"".MsEvalWith());
                var triangle = new Polyhedron();
                triangle.AddFacet(tetrahedron.Facets.Skip(1).First().CloneWithAllHalfEdgesCloned);
                return triangle;
            }
        }
    }
}
