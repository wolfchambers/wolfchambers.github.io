﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wolfram.NETLink;

namespace PolyLink
{
    public interface IExpressible
    {
        Expr AsExpr();
    }

    public static class MathHelper
    {
        
        /// <summary>
        /// Casts an IEnumerable into an array of objects, so mathematica can work with them.
        /// </summary>
        /// <param name="objects"></param>
        /// <returns></returns>
        public static object[] ToList(IEnumerable objects)
        {
            return objects.Cast<object>().ToArray();
        }

        /*public static IEnumerable<Expr> CastToExpr<T>(IEnumerable<T> expressibles) where T : IExpressible
        {
            return expressibles.Select(c => c.AsExpr());
        }*/


    }
}
