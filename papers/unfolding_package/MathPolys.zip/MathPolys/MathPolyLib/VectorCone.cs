﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wolfram.NETLink;

namespace PolyLink
{
    public struct ConeReturn
    {
        public VectorCone Left { get; set; }
        public VectorCone Right { get; set; }

        public static ConeReturn Failed
        {
            get
            {
                return new ConeReturn
                    {
                        Left = null,
                        Right = null,
                    };
            }
        }
    }

    public class VectorCone : MathLinked
    {
        private bool _valid;

        private readonly VectorCone _parent;
        private VectorCone _left;
        private VectorCone _right;
        private readonly WorkingCopy<HalfEdge> _currentEdge;
        private readonly Vector _lBind;
        private readonly Vector _rBind;
        private readonly VectorCSPF _cspf;
        private readonly PointRef _transformedEndPoint;

        public VectorCone(VectorCone parent, WorkingCopy<HalfEdge> currentEdge, VectorCSPF cspf, Vector lBind, Vector rBind, PointRef transformedEndPoint)
        {
            _parent = parent;
            _currentEdge = currentEdge;
            _cspf = cspf;
            _lBind = lBind;
            _rBind = rBind;
            _valid = true;
            _transformedEndPoint = transformedEndPoint;
        }

        public Facet CurrentFacet
        {
            get { return CurrentEdge.Original.Facet; }
        }

        public string CurrentFacetTag
        {
            get { return CurrentEdge.Original.Facet.Tag; }
        }

        public bool Valid
        {
            get { return _valid; }
        }

        public WorkingCopy<HalfEdge> CurrentEdge
        {
            get { return _currentEdge; }
        }

        public Vector LBind
        {
            get { return _lBind; }
        }

        public Vector RBind
        {
            get { return _rBind; }
        }

        public void Invalidate()
        {
            if (_left != null)
            {
                _left.Invalidate();
            }
            if (_right != null)
            {
                _right.Invalidate();
            }
            _valid = false;
        }

        public ConeReturn TryExtend()
        {
            if (_transformedEndPoint != null)
            {
                var vectorToEnd = new Vector(_transformedEndPoint.Expr);
                if (!_cspf.SeeIfConeHasShortestPath(this, vectorToEnd, _cspf.EndPoint))
                {
                    Invalidate();
                    return ConeReturn.Failed;
                }
            }

            var oppPoint = CurrentEdge.Copy.Next.End;
            var vectorToOpp = new Vector(oppPoint.Expr);

            var lCompare = VectorMath.SignedAngle(vectorToOpp, LBind).CompareTo();
            var rCompare = VectorMath.SignedAngle(vectorToOpp, RBind).CompareTo();

            if (lCompare == 0 || lCompare != rCompare)
            {
                if (!_cspf.SeeIfConeHasShortestPath(this, vectorToOpp, CurrentEdge.Original.Next.End))
                {
                    Invalidate();
                    return ConeReturn.Failed;
                }
            }

            if (lCompare.EqualsAny(0, 1))
            {
                var leftHE = CurrentEdge.Original.Prev.Opposite;
                var newHE = new WorkingCopy<HalfEdge>(leftHE, leftHE.FacetCloneWithOriginalOpposites);

                IEnumerable<PointRef> newEndPoint = null;

                //Move the new working copy.
                if (newHE.Original.Facet == _cspf.EndFacet)
                {
                    newEndPoint = new[] {_cspf.EndPoint.DeepClone};
                }
                newHE.Copy.Opposite = CurrentEdge.Copy.Prev;
                newHE.Copy.Unfold(newEndPoint);
                newHE.Copy.Opposite = CurrentEdge.Original.Prev;

                var rBind = (rCompare > 0) ? vectorToOpp : RBind;

                PointRef endPoint = (newEndPoint != null) ? newEndPoint.First() : null;

                _left = new VectorCone(
                    parent: this,
                    currentEdge: newHE,
                    cspf: _cspf,
                    lBind: LBind,
                    rBind: rBind,
                    transformedEndPoint: endPoint
                    );
            }

            if (rCompare.EqualsAny(0, -1))
            {
                var rightHE = CurrentEdge.Original.Next.Opposite;
                var newHE = new WorkingCopy<HalfEdge>(rightHE, rightHE.FacetCloneWithOriginalOpposites);

                IEnumerable<PointRef> newEndPoint = null;

                //Move the new working copy.
                if (newHE.Original.Facet == _cspf.EndFacet)
                {
                    newEndPoint = new[] { _cspf.EndPoint.DeepClone };
                }
                newHE.Copy.Opposite = CurrentEdge.Copy.Next;
                newHE.Copy.Unfold(newEndPoint);
                newHE.Copy.Opposite = CurrentEdge.Original.Next;

                PointRef endPoint = (newEndPoint != null) ? newEndPoint.First() : null;

                var lBind = (lCompare < 0) ? vectorToOpp : LBind;

                _right = new VectorCone(
                    parent: this,
                    currentEdge: newHE,
                    cspf: _cspf,
                    lBind: lBind,
                    rBind: RBind,
                    transformedEndPoint: endPoint
                    );
            }

            return new ConeReturn
                {
                    Left = _left,
                    Right = _right,
                };
        }

        public Expr Aperture
        {
            get { return VectorMath.SignedAngle(RBind, LBind); }
        }

        public IEnumerable<VectorCone> ChainToParents
        {
            get
            {
                var x = this;
                while (x != null)
                {
                    yield return x;
                    x = x._parent;
                }
            }
        }

        public string Representation
        {
            get
            {
                return "Graphics3D[" + ML["List"].Bracket(
                        ML["List"].Bracket(ChainToParents.Select(p => p.CurrentEdge.Copy.ForceNewFacet.Graphics)).Eval(),
                        ML["Arrow"].Bracket(ML["List"].Bracket(PointRef.Origin, LBind.Expr).Eval()).Eval(),
                        ML["Arrow"].Bracket(ML["List"].Bracket(PointRef.Origin, RBind.Expr).Eval()).Eval(),
                        _cspf.StartGraphics
                    ).Eval().ToString() + "]";
            }
        }
    }

    static class VectorMath
    {
        public static Expr SignedAngle(Vector vector1, Vector vector2)
        {
            return "Sign[Dot[{{ -{0}[[2]], {0}[[1]], 0 }}, {1}]]*ArcCos[Dot[Normalize[{0}], Normalize[{1}]]]"
                .MsEvalWith(vector1.Expr, vector2.Expr);
        }
    }
}
