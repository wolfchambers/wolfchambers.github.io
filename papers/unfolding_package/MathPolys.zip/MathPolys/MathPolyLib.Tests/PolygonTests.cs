﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using Wolfram.NETLink;

namespace MathPolyLib.Tests
{
    [TestFixture]
    public class PolygonTests
    {
        [Test]
        public void GraphicsCollectsFromFacets()
        {
            var p = new Polyhedron();
            var f = Facet.TestQuad;
            p.AddFacet(f);
            var g = p.Graphics
                .Parts().First()
                .Parts().First();
            Assert.AreEqual(g, f.Graphics);
        }
    }
}
