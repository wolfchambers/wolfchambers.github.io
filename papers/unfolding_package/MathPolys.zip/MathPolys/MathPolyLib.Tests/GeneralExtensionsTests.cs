﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using MathPolyLib;

namespace MathPolyLib.Tests
{
    [TestFixture]
    public class GeneralExtensionsTests
    {
        [Test]
        public void FmtFormats()
        {
            Assert.AreEqual(
                expected: String.Format("Foot {0}", "Ball"),
                actual: "Foot {0}".Fmt("Ball")
                );
        }

        [Test]
        public void CircularPairsWorksForFirstElement()
        {
            var cp = (new[] {1, 2, 3, 4, 5}).CirclularPairs();
            Func<Tuple<int,int>, int[], bool> comp2 = (a, b) => (a.Item1 == b[0]) && (a.Item2 == b[1]);
            Assert.IsTrue(comp2(cp.First(), new[] {1,2}));
        }

        [Test]
        public void CircularPairsWorksForLastElement()
        {
            var cp = (new[] { 1, 2, 3, 4, 5 }).CirclularPairs();
            Func<Tuple<int, int>, int[], bool> comp2 = (a, b) => (a.Item1 == b[0]) && (a.Item2 == b[1]);
            Assert.IsTrue(comp2(cp.Last(), new[] { 5, 1 }));
        }

        [Test]
        public void CircularTripletsWorksForFirstElement()
        {
            var ct = (new[] {1, 2, 3, 4, 5}).CircularTuples(3);
            var first = ct.First();
            Assert.IsTrue(first[0] == 1 && first[2] == 3);
        }

        [Test]
        public void CircularTripletsWorksForLastElement()
        {
            var ct = (new[] {1, 2, 3, 4, 5}).CircularTuples(3);
            var first = ct.Last();
            Assert.IsTrue(first[0] == 5 && first[2] == 2);
        }
    }
}
