﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using Wolfram.NETLink;
using MathPolyLib;

namespace MathPolyLib.Tests
{
    [TestFixture]
    public class NetLinkExtensionsTests
    {
        [Test]
        public void PartsReturnsParts()
        {
            var listy = "{ 1, 2, 3}".MsEvalWith();
            var parts = listy.Parts().Select(n => n.AsInt64()).ToList();
            var n1 = parts.Skip(0).First();
            var n2 = parts.Skip(1).First();
            var n3 = parts.Skip(2).First();
            Assert.AreEqual(n1, 1);
            Assert.AreEqual(n2, 2);
            Assert.AreEqual(n3, 3);
        }
    }
}
