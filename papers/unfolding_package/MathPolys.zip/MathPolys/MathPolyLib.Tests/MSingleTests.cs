﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using Wolfram.NETLink;

namespace MathPolyLib.Tests
{
    [TestFixture]
    public sealed class MSingleTests
    {


        /*
        //Singleton code
        private static readonly Lazy<MSingle> Lazy =  new Lazy<MSingle>(() => new MSingle());

        public static MSingle Instance
        {
            get { return Lazy.Value; }
        }

        public static IKernelLink Kernel
        {
            get { return Instance.KernelLink; }
        }

        public IKernelLink KernelLink
        {
            get { return _kernelLink; }
        }

        //Other stuff
        private readonly IKernelLink _kernelLink;

        private MSingle()
        {
            _kernelLink = MathLinkFactory.CreateKernelLink();
            _kernelLink.WaitAndDiscardAnswer();
        }

        public static Expr Eval(String s, params object[] args)
        {
            var sf = String.Format(s, args);
            Kernel.Evaluate(sf);
            Kernel.WaitForAnswer();
            var e = Kernel.GetExpr();
            return e;
        }

        public static Expr EvalFunction(String functionName, IEnumerable<Expr> args)
        {
            return Eval("{0}[{1}]", functionName, String.Join(",", args));
        }
         */
    }

    [TestFixture]
    public class MSingleExtensionsTests
    {
        /*
        public static Expr MsEvalWith(this String s, params object[] args)
        {
            return MSingle.Eval(s, args);
        }

        public static Expr MsBracket(this String s, IEnumerable<Expr> args)
        {
            return MSingle.EvalFunction(s, args);
        }

        public static Expr MsBracket(this String s, Expr arg)
        {
            return s.MsBracket(new[]{arg});
        }

       /* This was creating a strange bug!!
        * 
        * 
        * 
        public static Expr MsBracket(this String s, params Expr[] args)
        {
            return s.MsBracket(args);
        }
        */
    }
}
