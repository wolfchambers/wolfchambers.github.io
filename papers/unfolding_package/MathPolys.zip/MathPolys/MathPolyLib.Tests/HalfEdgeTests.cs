﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using Wolfram.NETLink;

namespace MathPolyLib.Tests
{

    [TestFixture]
    public class EndPointPacketTests
    {
        [Test]
        public void ConstructorPreservesStartAndEnd()
        {
            var epp = new EndPointPacket(PointRef.OriginRef, PointRef.Ref100);
            Assert.AreSame(actual: epp.StartRef,
                expected: PointRef.OriginRef);
            Assert.AreSame(actual: epp.EndRef,
                expected: PointRef.Ref100);
        }

        [Test]
        public void OppositeIsOpposite()
        {
            var epp = new EndPointPacket(PointRef.OriginRef, PointRef.Ref100);
            var opp = epp.Opposite;
            Assert.AreSame(actual: opp.EndRef,
                expected: PointRef.OriginRef);
            Assert.AreSame(actual: opp.StartRef,
                expected: PointRef.Ref100);
        }
    }

    [TestFixture]
    public class PlaneTests
    {
        [Test]
        public void ConstructorPreservesPointAndNormal()
        {
            var plane = Plane.TestOriginUp;
            Assert.AreEqual(actual: plane.Point,
                expected: PointRef.Origin);
        }
    }

    [TestFixture]
    public class HalfEdgeTests
    {
        [Test]
        public void ConstructorPreservesStartEnd()
        {
            var he = HalfEdge.Facetable;
            Assert.AreEqual(expected: PointRef.OriginRef,
                actual: he.Start);
            Assert.AreEqual(expected: PointRef.Ref100,
                actual: he.End);
        }


        [Test]
        public void EndPointPacketPreservesStartEnd()
        {
            var he = HalfEdge.LittleLine;
            var epp = new EndPointPacket(PointRef.OriginRef, PointRef.Ref100);
            Assert.AreEqual(expected: epp,
                actual: he.EndPointPacket);
        }

        [Test]
        public void OppositeEndPointPacketSwapsStartAndEnd()
        {
            var he = HalfEdge.LittleLine;
            var oepp = new EndPointPacket(PointRef.Ref100, PointRef.OriginRef);
            Assert.AreEqual(expected: oepp,
                actual: he.OppositesEndPointPacket);
        }

        [Test]
        public void HesFromHereReversedIsBackwardsly()
        {
            var he = HalfEdge.Facetable;
            var he2 = he.HEsFromHereReversed.Skip(2).First();
            Assert.AreSame(he2.Next.Next, he);
        }

        [Test]
        public void HesFromHereReversedIsFinite()
        {
            var he = HalfEdge.Facetable;
            Assert.AreEqual(he.HEsFromHereReversed.Count(), 3);
        }

        

        /*

        public Expr DotOpposite
        {
            get { return "Dot[{0},{1}]".MsEvalWith(this.Plane.Normal, Opposite.Plane.Normal); }
        }
        public void MergeAcross()
        {
            Prev.LinkNext(Opposite.Next);
            Opposite.Prev.LinkNext(Next);
        }
         */
    }
}
