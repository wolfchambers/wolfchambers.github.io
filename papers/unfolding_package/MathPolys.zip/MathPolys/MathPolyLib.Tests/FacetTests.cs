﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using MathPolyLib;
using Wolfram.NETLink;

namespace MathPolyLib.Tests
{
    [TestFixture]
    public class FacetTests
    {
        [TestFixtureSetUp]
        public void Setup()
        {
            "3".MsEvalWith();
            "5".MsEvalWith();
        }

        public static Facet NewTestFacet(HalfEdge h = null, string color = "Red")
        {
            if (h == null)
            {
                h = HalfEdge.Facetable;
            }
            return new Facet(h, color);
        }

        [Test]
        public void TestConstructorKeepsHead()
        {
            Assert.AreSame(HalfEdge.Facetable, NewTestFacet().Head);
        }

        [Test]
        public void TestConstructorThrowsIfColorWrong()
        {
            Assert.Throws<ArgumentException>(() => NewTestFacet(color: "asdfsdjflsdafs"));
        }

        [Test]
        public void RedFacetIsRed()
        {
            var facet = NewTestFacet();
            Assert.AreEqual(actual:facet.Color.ToString(),
                expected:"RGBColor[1,0,0]");
        }

        [Test]
        public void FacetNormalPointsUp()
        {
            Assert.AreEqual(
                expected: 1,
                actual: NewTestFacet().Plane.Normal.Part(3).AsInt64());
        }

        [Test]
        public void FacetNormalHasZeroZ()
        {
            Assert.AreEqual(
                actual: NewTestFacet().Plane.Point.Part(3).AsInt64(),
                expected: 0);
        }

        [Test]
        public void FiniteHalfEdgesWithFacetable()
        {
            Assert.AreEqual(NewTestFacet().HalfEdges.Count(),3);
        }

        [Test]
        public void GraphicsDoesNotThrowError()
        {
            Expr g;
            Assert.DoesNotThrow(() => g = NewTestFacet().Graphics);
        }

        [Test]
        public void SubDivideDoesNotIncreaseHalfEdgeCount()
        {
            var quad = Facet.TestQuad;
            var four = quad.HalfEdges.Count();
            quad.SubDivide(quad.HalfEdges.First().Start, quad.HalfEdges.Skip(2).First().Start);
            Assert.IsTrue(four >= quad.HalfEdges.Count());
        }

        [Test]
        public void SubDividePreservesHead()
        {
            var quad = Facet.TestQuad;
            var originalHead = quad.Head;
            var four = quad.HalfEdges.Count();
            quad.SubDivide(quad.HalfEdges.First().Start, quad.HalfEdges.Skip(2).First().Start);
            Assert.AreSame(originalHead, quad.Head);
        }

        [Test]
        public void SubDivideCreatesClosedFacets()
        {
            var quad = Facet.TestQuad;
            var four = quad.HalfEdges.Count();
            var f2 = quad.SubDivide(quad.HalfEdges.First().Start, quad.HalfEdges.Skip(2).First().Start);
            Assert.AreEqual(f2.HalfEdges.Count(), quad.HalfEdges.Count());
        }

        [Test]
        public void PointRefsGivesStartPoints()
        {
            var quad = Facet.TestQuad;
            Assert.AreEqual(quad.PointRefs.First(), PointRef.OriginRef);
        }

        [Test]
        public void PointRefArrayIsPointRefsAsArray()
        {
            var quad = Facet.TestQuad;
            Assert.AreEqual(quad.PointRefs.ToArray()[0],quad.PointRefArray[0]);
            Assert.AreEqual(quad.PointRefs.ToArray()[2], quad.PointRefArray[2]);
        }

        [Test]
        public void PointsHasListHead()
        {
            var quad = Facet.TestQuad;
            var pl = quad.Points;
            Assert.AreEqual(pl.Head.ToString(),"List");
        }
    }
}
