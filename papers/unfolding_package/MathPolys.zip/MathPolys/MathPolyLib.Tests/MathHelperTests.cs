﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using Wolfram.NETLink;
using MathPolyLib;

namespace MathPolyLib.Tests
{
    [TestFixture]
    public class MathHelperTests
    {
        [Test]
        public void ToListDoesNotThrowException()
        {
            var list = new List<int>{1, 2, 3, 4, 5, 6, 7};
            Assert.DoesNotThrow(() => MathHelper.ToList(list));
        }

        [Test]
        public void ToListDoesNotThowWithRefType()
        {
            var listy = new List<int>();
            var lol = new List<List<int>> {listy, listy, listy, listy, listy};
            Assert.DoesNotThrow(() => MathHelper.ToList(lol));
        }



        /*
        public static object[] ToList(IEnumerable objects)
        {
            return objects.Cast<object>().ToArray();
        }

        public static IEnumerable<Expr> CastToExpr<T>(IEnumerable<T> expressibles) where T : IExpressible
        {
            return expressibles.Select(c => c.AsExpr());
        }
        */

    }
}
