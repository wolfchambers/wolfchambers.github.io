﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WhatsMyOSVersion
{
    class Program
    {
        static void Main(string[] args)
        {
            int v = (int) System.Environment.OSVersion.Platform;
            Console.WriteLine("OSVersion.Platform is " + v);
            Console.ReadKey();
        }
    }
}
