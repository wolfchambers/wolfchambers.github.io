﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MathPolyLib;

namespace ConsoleSandbox
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("dink");


            var cubeName = "\"Cube\"".MsEvalWith();
            var cube = PolyIO.PolyFromName(cubeName);
            cube.Triangulate();
            cube.TagFacets();
            cube.ForceHalfEdgesToReferenceFacets();
            var f1 = cube.Facets.First();
            var f5 = cube.Facets.Skip(4).First();

            //var spf = new ConvexShortestPathFinder(cube, f1.Head, new PointRef("{.3,.3,.5}".MsEvalWith()),
              //                                     f5, new PointRef("-{.3,.3,.5}".MsEvalWith()));

            var cspf = new VectorCSPF(cube, f1.Head, f5, new PointRef("{.3,.3,.5}".MsEvalWith()),
                                      new PointRef("-{.3,.3,.5}".MsEvalWith()));
            var path = cspf.ComputeShortestPath();

            //var path = spf.ComputeShortestPath();


            /*
            var pA = PointRef.PointFromInts(-1, 1, 0);
            var pB = PointRef.PointFromInts( 2, 1, 0);
            var pC = PointRef.PointFromInts( 3, 1, 0);
            var pD = PointRef.PointFromInts( 2, 0, 0);
            var pE = PointRef.PointFromInts( 0, 0, 0);
                                                      
            var ba = new HalfEdge(pB, pA);
            var ae = new HalfEdge(pA, pE);
            var eb = new HalfEdge(pE, pB);
            var be = new HalfEdge(pB, pE);
            var ed = new HalfEdge(pE, pD);
            var db = new HalfEdge(pD, pB);
            var bd = new HalfEdge(pB, pD);
            var dc = new HalfEdge(pD, pC);
            var cb = new HalfEdge(pC, pB);

            ba.LinkNext(ae);
            ae.LinkNext(eb);
            eb.LinkNext(ba);
            be.LinkNext(ed);
            ed.LinkNext(db);
            db.LinkNext(be);
            bd.LinkNext(dc);
            dc.LinkNext(cb);
            cb.LinkNext(bd);

            eb.Opposite = be;
            be.Opposite = eb;
            db.Opposite = bd;
            bd.Opposite = db;

            var poly = new Polyhedron();
            poly.AddFacet(new Facet(ed));
            poly.AddFacet(new Facet(ba));
            poly.AddFacet(new Facet(bd));

            var coneStart = MSingle.Eval("{1,-1,0}");

            var c = new Cone(parent: null,
                     currentCrossedHalfEdge: ed,
                     relativeSource: coneStart,
                     relativeAngleL: MSingle.Eval("-.2"),
                     relativeAngleR: MSingle.Eval("-1.4"),
                     absoluteSourceToCorner: MSingle.Eval("3*Pi/4"));

            c.TryExtend(new TestConvextShortestPathFinder());*/

            Console.ReadKey();
        }                                             
    }                                                 
}                                                     
                                                      